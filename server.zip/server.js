const express = require('express');
const { Client, Intents } = require('discord.js');
const fs = require('fs');
const fs2 = require('fs').promises;
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const http = require('http');
const WebSocket = require('ws');
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const axios = require('axios');
const crypto = require('crypto');
app.use(express.json()); // Use express.json() for parsing JSON bodies
const geoip = require('geoip-lite');
const ISO3166 = require('iso-3166-1');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const session = require('express-session');
const quickemailverification = require('quickemailverification').client('ebdc4d5d1777f9e10092bcc5f8c267d5a7f2c3064aa72c7741b2a0d8522a').quickemailverification();
const sgMail = require('@sendgrid/mail')
sgMail.setApiKey('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')
const moment = require('moment');
const multer = require('multer');
require('dotenv').config();
const { URLSearchParams } = require('url');
const cron = require('node-cron');
const fs3 = require('fs-extra');

let profilesFolder = path.join(__dirname, 'data', 'profiles');

// Middleware to block access to routes containing /private but not /login
function blockPrivateRoutes(req, res, next) {
  // Check if the request is for the /login route
  if (req.path === '/editor' || req.path === '/upload-profile' || req.path === '/download-profile' || req.path === '/logout' || req.path === '/moderator-delete-profile' || req.path === '/moderator-delete-author' || req.path === '/moderator-verify-author' || req.path === '/update-visibility-profile' || req.path === '/profiles-edit' || req.path === '/profiles-edit-2' || req.path === '/login' || req.path === '/login-auto' || req.path === '/public-webhook' || req.path === '/discord-oauth-callback') {
    // If the request is for /login, allow access
    next();
  } else if (req.path.includes('/private') || req.path.includes('/server.js') || req.path.includes('/uploads') || req.path.includes('/token.txt') || req.path.includes('/webhook.txt') || req.path.includes('/webhook_view.txt')) {
    // If the request includes /private but is not for /login, send a 403 Forbidden response
    res.status(403).json({ success: false, message: 'Forbidden' });
  } else {
    // For other requests, allow access
    next();
  }
}

// Endpoint to access webhook.txt
app.get('/public-webhook', (req, res) => {
  const filePath = path.join(__dirname, 'webhook.txt');
  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Failed to read webhook file' });
    }
    res.status(200).send(data);
  });
});










// Function to clear the require cache
function clearRequireCache() {
  Object.keys(require.cache).forEach((key) => {
    if (key.endsWith('.js')) {
      delete require.cache[key];
    }
  });
}

// Clear cache on server start
clearRequireCache();



























// Example function to check if a profile ID exists recursively in subfolders
function profileExists(profileId, folderPath) {
  // Ensure folderPath is provided and is a directory
  if (!fs.existsSync(folderPath) || !fs.lstatSync(folderPath).isDirectory()) {
    return false;
  }

  // Function to recursively search for the profile file
  function searchFolder(currentPath) {
    const files = fs.readdirSync(currentPath);

    for (const file of files) {
      const filePath = path.join(currentPath, file);

      if (fs.lstatSync(filePath).isDirectory()) {
        // Recursively search subfolders
        if (searchFolder(filePath)) {
          return true;
        }
      } else if (file === `${profileId}.json`) {
        // Found the profile file
        return true;
      }
    }

    return false; // Profile file not found in current folder or its subfolders
  }

  // Start searching from the provided folderPath
  return searchFolder(folderPath);
}

  // Serve the index.html file when accessing /edit/:id
  app.get('/editor/:id', (req, res) => {
    const id_load = req.params.id;

    // Read the contents of index.html
    const htmlPath = path.join(__dirname, 'editor.html');
    fs.readFile(htmlPath, 'utf8', (err, data) => {
      if (err) {
        console.error('Error reading index.html:', err);
        return res.status(500).send('Error loading index.html');
      }
  
      // Replace a placeholder string with id_load in the HTML content
      const modifiedHtml = data.replace('${uniqueID}', id_load);
  
      // Send the modified HTML to the client
      res.send(modifiedHtml);
    });
  });

// Example usage:
app.use(blockPrivateRoutes);

// Path to the folder containing user JSON files
const userDataFolderPath = './users/private';

// Function to read user data from the JSON file
const readUserData = (filename) => {
    try {
        const filePath = path.join(userDataFolderPath, filename);
        const userData = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(userData);
    } catch (error) {
        console.error('Error reading user data:', error);
        return null;
    }
};

app.use(bodyParser.json());

const profilesDir = path.join(__dirname, 'profiles'); // Directory where profiles are stored

// Mock function to check login status
function checkLogin(req) {
    // This should be replaced with your actual authentication logic
    return { loggedIn: true, userData: { id: '123', username: 'testUser' } };
}

// Mock function to fetch profiles
function fetchProfiles() {
    // This should be replaced with your actual logic to fetch profiles
    return JSON.parse(fs.readFileSync(path.join(profilesDir, 'profiles.json'), 'utf8'));
}

// Mock function to delete a profile file
function deleteProfileFile(profileId) {
    const filePath = path.join(profilesDir, `${profileId}.json`);
    if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        return true;
    }
    return false;
}




// Endpoint to handle profile deletion
app.delete('/moderator-delete-profile/:moderator/:id/:owner/:token', async (req, res) => {
  const token = req.params.token;

  if (!token) {
      console.log('No token found in request parameters');
      return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensJson;
  try {
      const tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
      tokensJson = JSON.parse(tokensContent);
  } catch (error) {
      console.error('Error reading or parsing tokens file:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
      console.log('User not found for token:', token);
      return res.status(401).json({ message: 'User not found.' });
  }

  console.log('Found user:', user);

  // Path to the user's private data file
  const userPrivateDataPath = path.join(__dirname, 'users', 'private', `${user.email}.json`);

  let userPrivateData;
  try {
      const userPrivateContent = await fs.promises.readFile(userPrivateDataPath, 'utf8');
      userPrivateData = JSON.parse(userPrivateContent);
  } catch (error) {
      console.error('Error reading or parsing user private data file:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  if (!userPrivateData.moderator) {
      console.log('User is not a moderator:', user.email);
      return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this profile.' });
  }

  const profileId = req.params.id;
  const modId = req.params.moderator;
  const profileowner = req.params.owner;

  console.log("Moderator ID:", modId)
  console.log("Private Data ID:", userPrivateData.id)
  console.log(`${modId}` === `${userPrivateData.id}`)

  if (`${modId}` === `${userPrivateData.id}`) { // Use strict equality for ID comparison

      // Construct the source and target file paths
      const sourceFilePath = path.join(__dirname, 'data', 'profiles', `${profileowner}`, 'public', `${profileId}.op5`);
      const targetFolderPath = path.join(__dirname, 'data', '.deleted', 'profiles', `${profileowner}`);
      const targetFilePath = path.join(targetFolderPath, `${profileId}.op5`);

      // Check if the source file exists
      if (!fs.existsSync(sourceFilePath)) {
          return res.status(404).json({ error: 'Source file does not exist.' });
      }

      // Create deleted folder if it doesn't exist
      if (!fs.existsSync(targetFolderPath)) {
          fs.mkdirSync(targetFolderPath, { recursive: true });
      }

      // Move file to deleted folder
      try {
          await fs.promises.rename(sourceFilePath, targetFilePath);
          console.log('Profile moved to .deleted folder:', profileId);
          res.json({ message: 'Profile deleted and moved to .deleted folder.' });
      } catch (err) {
          console.error('Error moving file:', err);
          return res.status(500).json({ error: 'Failed to move profile to .deleted folder.' });
      }
  } else {
      console.log('Unauthorized: Moderator ID does not match user ID.');
      return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this profile.' });
  }
});











app.delete('/moderator-delete-author/:moderator/:id/:owner/:token/:ban', async (req, res) => {
  const { moderator, id, owner, token, ban } = req.params;

  if (!token) {
    console.log('No token found in request parameters');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensJson;
  try {
    const tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
    tokensJson = JSON.parse(tokensContent);
    console.log('Tokens file read successfully:', tokensJson);
  } catch (error) {
    console.error('Error reading or parsing tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  console.log('Found user:', user);

  const userPrivateDataPath = path.join(__dirname, 'users', 'private', `${user.email}.json`);

  let userPrivateData;
  try {
    const userPrivateContent = await fs.promises.readFile(userPrivateDataPath, 'utf8');
    userPrivateData = JSON.parse(userPrivateContent);
    console.log('User private data read successfully:', userPrivateData);
  } catch (error) {
    console.error('Error reading or parsing user private data file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  if (!userPrivateData.moderator) {
    console.log('User is not authorized as a moderator:', user.email);
    return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this profile.' });
  }

  const privateFolderPath = path.join(__dirname, 'users', 'private');
  const deletedAuthorsPath = path.join(__dirname, 'data', '.deleted', 'authors');

  let authorFilePath;
  let privateFilePath;

  try {
    const files = await fs.promises.readdir(privateFolderPath);
    console.log('Private folder files read successfully:', files);

    for (const file of files) {
      if (file.endsWith('.json')) {
        const filePath = path.join(privateFolderPath, file);
        const fileContent = await fs.promises.readFile(filePath, 'utf8');
        const profile = JSON.parse(fileContent);

        console.log(`Checking profile with ID ${profile.id} against provided ID ${id}`);

        if (`${profile.id}` === `${id}`) {
          authorFilePath = path.join(__dirname, 'data', 'authors', `${profile.username}.json`);
          privateFilePath = filePath;
          console.log('Match found. Author file path:', authorFilePath);
          console.log('Private file path:', privateFilePath);
          break;
        }
      }
    }

    if (!authorFilePath || !privateFilePath) {
      console.log('Profile not found for ID:', id);
      return res.status(404).json({ message: 'Profile not found.' });
    }

    const authorData = await fs.promises.readFile(authorFilePath, 'utf8');
    let authorProfile = JSON.parse(authorData);

    console.log('Author profile before update:', authorProfile);

    authorProfile.banned = true;

    await fs.promises.writeFile(authorFilePath, JSON.stringify(authorProfile, null, 2), 'utf8');
    console.log('Author profile updated as banned:', authorProfile);

    const privateData = await fs.promises.readFile(privateFilePath, 'utf8');
    let privateProfile = JSON.parse(privateData);

    console.log('Private profile before update:', privateProfile);

    privateProfile.banned = true;
    privateProfile.ban_reason = `${ban}`;

    await fs.promises.writeFile(privateFilePath, JSON.stringify(privateProfile, null, 2), 'utf8');
    console.log('Private profile updated as banned:', privateProfile);

    // Ensure the .deleted/authors directory exists
    await fs.promises.mkdir(deletedAuthorsPath, { recursive: true });
    console.log('Ensured .deleted/authors directory exists:', deletedAuthorsPath);

    // Move the banned author profile to the .deleted/authors directory
    const deletedAuthorFilePath = path.join(deletedAuthorsPath, path.basename(authorFilePath));
    await fs.promises.rename(authorFilePath, deletedAuthorFilePath);
    console.log('Banned author profile moved to .deleted/authors:', deletedAuthorFilePath);

    res.json({ message: 'Profiles marked as banned.' });
  } catch (error) {
    console.error('Error updating profiles:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
});























app.delete('/moderator-verify-author/:moderator/:id/:owner/:token', async (req, res) => {
  const { moderator, id, owner, token } = req.params;

  if (!token) {
    console.log('No token found in request parameters');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensJson;
  try {
    const tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
    tokensJson = JSON.parse(tokensContent);
    console.log('Tokens file read successfully:', tokensJson);
  } catch (error) {
    console.error('Error reading or parsing tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  console.log('Found user:', user);

  const userPrivateDataPath = path.join(__dirname, 'users', 'private', `${user.email}.json`);

  let userPrivateData;
  try {
    const userPrivateContent = await fs.promises.readFile(userPrivateDataPath, 'utf8');
    userPrivateData = JSON.parse(userPrivateContent);
    console.log('User private data read successfully:', userPrivateData);
  } catch (error) {
    console.error('Error reading or parsing user private data file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  if (!userPrivateData.moderator) {
    console.log('User is not authorized as a moderator:', user.email);
    return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this profile.' });
  }

  const privateFolderPath = path.join(__dirname, 'users', 'private');

  let privateFilePath;
  let authorFilePath;

  try {
    const files = await fs.promises.readdir(privateFolderPath);
    console.log('Private folder files read successfully:', files);

    for (const file of files) {
      if (file.endsWith('.json')) {
        const filePath = path.join(privateFolderPath, file);
        const fileContent = await fs.promises.readFile(filePath, 'utf8');
        const profile = JSON.parse(fileContent);

        console.log(`Checking profile with ID ${profile.id} against provided ID ${id}`);

        if (`${profile.id}` === `${id}`) {
          authorFilePath = path.join(__dirname, 'data', 'authors', `${profile.username}.json`);
          privateFilePath = filePath;
          console.log('Match found. Author file path:', authorFilePath);
          console.log('Private file path:', privateFilePath);
          break;
        }
      }
    }

    if (!authorFilePath || !privateFilePath) {
      console.log('Profile not found for ID:', id);
      return res.status(404).json({ message: 'Profile not found.' });
    }

    const authorData = await fs.promises.readFile(authorFilePath, 'utf8');
    let authorProfile = JSON.parse(authorData);

    console.log('Author profile before update:', authorProfile);

    authorProfile.verified = !authorProfile.verified;

    await fs.promises.writeFile(authorFilePath, JSON.stringify(authorProfile, null, 2), 'utf8');
    console.log('Author profile updated as verified:', authorProfile);

    const privateData = await fs.promises.readFile(privateFilePath, 'utf8');
    let privateProfile = JSON.parse(privateData);

    console.log('Private profile before update:', privateProfile);

    privateProfile.verified = authorProfile.verified;

    await fs.promises.writeFile(privateFilePath, JSON.stringify(privateProfile, null, 2), 'utf8');
    console.log('Private profile updated as verified:', privateProfile);

    res.json({ message: 'Profiles marked as verified.' });
  } catch (error) {
    console.error('Error updating profiles:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
});








app.delete('/moderator-early-author/:moderator/:id/:owner/:token', async (req, res) => {
  const { moderator, id, owner, token } = req.params;

  if (!token) {
    console.log('No token found in request parameters');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensJson;
  try {
    const tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
    tokensJson = JSON.parse(tokensContent);
    console.log('Tokens file read successfully:', tokensJson);
  } catch (error) {
    console.error('Error reading or parsing tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  console.log('Found user:', user);

  const userPrivateDataPath = path.join(__dirname, 'users', 'private', `${user.email}.json`);

  let userPrivateData;
  try {
    const userPrivateContent = await fs.promises.readFile(userPrivateDataPath, 'utf8');
    userPrivateData = JSON.parse(userPrivateContent);
    console.log('User private data read successfully:', userPrivateData);
  } catch (error) {
    console.error('Error reading or parsing user private data file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  if (!userPrivateData.moderator) {
    console.log('User is not authorized as a moderator:', user.email);
    return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this profile.' });
  }

  const privateFolderPath = path.join(__dirname, 'users', 'private');

  let privateFilePath;
  let authorFilePath;

  try {
    const files = await fs.promises.readdir(privateFolderPath);
    console.log('Private folder files read successfully:', files);

    for (const file of files) {
      if (file.endsWith('.json')) {
        const filePath = path.join(privateFolderPath, file);
        const fileContent = await fs.promises.readFile(filePath, 'utf8');
        const profile = JSON.parse(fileContent);

        console.log(`Checking profile with ID ${profile.id} against provided ID ${id}`);

        if (`${profile.id}` === `${id}`) {
          authorFilePath = path.join(__dirname, 'data', 'authors', `${profile.username}.json`);
          privateFilePath = filePath;
          console.log('Match found. Author file path:', authorFilePath);
          console.log('Private file path:', privateFilePath);
          break;
        }
      }
    }

    if (!authorFilePath || !privateFilePath) {
      console.log('Profile not found for ID:', id);
      return res.status(404).json({ message: 'Profile not found.' });
    }

    const authorData = await fs.promises.readFile(authorFilePath, 'utf8');
    let authorProfile = JSON.parse(authorData);

    console.log('Author profile before update:', authorProfile);

    authorProfile.early = !authorProfile.early;

    await fs.promises.writeFile(authorFilePath, JSON.stringify(authorProfile, null, 2), 'utf8');
    console.log('Author profile updated as early:', authorProfile);

    const privateData = await fs.promises.readFile(privateFilePath, 'utf8');
    let privateProfile = JSON.parse(privateData);

    console.log('Private profile before update:', privateProfile);

    privateProfile.early = authorProfile.early;

    await fs.promises.writeFile(privateFilePath, JSON.stringify(privateProfile, null, 2), 'utf8');
    console.log('Private profile updated as early:', privateProfile);

    res.json({ message: 'Profiles marked as early.' });
  } catch (error) {
    console.error('Error updating profiles:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
});





app.delete('/moderator-premium-author/:moderator/:id/:owner/:token', async (req, res) => {
  const { moderator, id, owner, token } = req.params;

  if (!token) {
    console.log('No token found in request parameters');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensJson;
  try {
    const tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
    tokensJson = JSON.parse(tokensContent);
    console.log('Tokens file read successfully:', tokensJson);
  } catch (error) {
    console.error('Error reading or parsing tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  console.log('Found user:', user);

  const userPrivateDataPath = path.join(__dirname, 'users', 'private', `${user.email}.json`);

  let userPrivateData;
  try {
    const userPrivateContent = await fs.promises.readFile(userPrivateDataPath, 'utf8');
    userPrivateData = JSON.parse(userPrivateContent);
    console.log('User private data read successfully:', userPrivateData);
  } catch (error) {
    console.error('Error reading or parsing user private data file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  if (!userPrivateData.moderator) {
    console.log('User is not authorized as a moderator:', user.email);
    return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this profile.' });
  }

  const privateFolderPath = path.join(__dirname, 'users', 'private');

  let privateFilePath;
  let authorFilePath;

  try {
    const files = await fs.promises.readdir(privateFolderPath);
    console.log('Private folder files read successfully:', files);

    for (const file of files) {
      if (file.endsWith('.json')) {
        const filePath = path.join(privateFolderPath, file);
        const fileContent = await fs.promises.readFile(filePath, 'utf8');
        const profile = JSON.parse(fileContent);

        console.log(`Checking profile with ID ${profile.id} against provided ID ${id}`);

        if (`${profile.id}` === `${id}`) {
          authorFilePath = path.join(__dirname, 'data', 'authors', `${profile.username}.json`);
          privateFilePath = filePath;
          console.log('Match found. Author file path:', authorFilePath);
          console.log('Private file path:', privateFilePath);
          break;
        }
      }
    }

    if (!authorFilePath || !privateFilePath) {
      console.log('Profile not found for ID:', id);
      return res.status(404).json({ message: 'Profile not found.' });
    }

    const authorData = await fs.promises.readFile(authorFilePath, 'utf8');
    let authorProfile = JSON.parse(authorData);

    console.log('Author profile before update:', authorProfile);

    authorProfile.premium = !authorProfile.premium;

    await fs.promises.writeFile(authorFilePath, JSON.stringify(authorProfile, null, 2), 'utf8');
    console.log('Author profile updated as premium:', authorProfile);

    const privateData = await fs.promises.readFile(privateFilePath, 'utf8');
    let privateProfile = JSON.parse(privateData);

    console.log('Private profile before update:', privateProfile);

    privateProfile.premium = authorProfile.premium;

    await fs.promises.writeFile(privateFilePath, JSON.stringify(privateProfile, null, 2), 'utf8');
    console.log('Private profile updated as premium:', privateProfile);

    res.json({ message: 'Profiles marked as premium.' });
  } catch (error) {
    console.error('Error updating profiles:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
});




app.delete('/moderator-contributor-author/:moderator/:id/:owner/:token', async (req, res) => {
  const { moderator, id, owner, token } = req.params;

  if (!token) {
    console.log('No token found in request parameters');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensJson;
  try {
    const tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
    tokensJson = JSON.parse(tokensContent);
    console.log('Tokens file read successfully:', tokensJson);
  } catch (error) {
    console.error('Error reading or parsing tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  console.log('Found user:', user);

  const userPrivateDataPath = path.join(__dirname, 'users', 'private', `${user.email}.json`);

  let userPrivateData;
  try {
    const userPrivateContent = await fs.promises.readFile(userPrivateDataPath, 'utf8');
    userPrivateData = JSON.parse(userPrivateContent);
    console.log('User private data read successfully:', userPrivateData);
  } catch (error) {
    console.error('Error reading or parsing user private data file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  if (!userPrivateData.moderator) {
    console.log('User is not authorized as a moderator:', user.email);
    return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this profile.' });
  }

  const privateFolderPath = path.join(__dirname, 'users', 'private');

  let privateFilePath;
  let authorFilePath;

  try {
    const files = await fs.promises.readdir(privateFolderPath);
    console.log('Private folder files read successfully:', files);

    for (const file of files) {
      if (file.endsWith('.json')) {
        const filePath = path.join(privateFolderPath, file);
        const fileContent = await fs.promises.readFile(filePath, 'utf8');
        const profile = JSON.parse(fileContent);

        console.log(`Checking profile with ID ${profile.id} against provided ID ${id}`);

        if (`${profile.id}` === `${id}`) {
          authorFilePath = path.join(__dirname, 'data', 'authors', `${profile.username}.json`);
          privateFilePath = filePath;
          console.log('Match found. Author file path:', authorFilePath);
          console.log('Private file path:', privateFilePath);
          break;
        }
      }
    }

    if (!authorFilePath || !privateFilePath) {
      console.log('Profile not found for ID:', id);
      return res.status(404).json({ message: 'Profile not found.' });
    }

    const authorData = await fs.promises.readFile(authorFilePath, 'utf8');
    let authorProfile = JSON.parse(authorData);

    console.log('Author profile before update:', authorProfile);

    authorProfile.contributor = !authorProfile.contributor;

    await fs.promises.writeFile(authorFilePath, JSON.stringify(authorProfile, null, 2), 'utf8');
    console.log('Author profile updated as contributor:', authorProfile);

    const privateData = await fs.promises.readFile(privateFilePath, 'utf8');
    let privateProfile = JSON.parse(privateData);

    console.log('Private profile before update:', privateProfile);

    privateProfile.contributor = authorProfile.contributor;

    await fs.promises.writeFile(privateFilePath, JSON.stringify(privateProfile, null, 2), 'utf8');
    console.log('Private profile updated as contributor:', privateProfile);

    res.json({ message: 'Profiles marked as contributor.' });
  } catch (error) {
    console.error('Error updating profiles:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
});


app.delete('/moderator-bughunter-author/:moderator/:id/:owner/:token', async (req, res) => {
  const { moderator, id, owner, token } = req.params;

  if (!token) {
    console.log('No token found in request parameters');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensJson;
  try {
    const tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
    tokensJson = JSON.parse(tokensContent);
    console.log('Tokens file read successfully:', tokensJson);
  } catch (error) {
    console.error('Error reading or parsing tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  console.log('Found user:', user);

  const userPrivateDataPath = path.join(__dirname, 'users', 'private', `${user.email}.json`);

  let userPrivateData;
  try {
    const userPrivateContent = await fs.promises.readFile(userPrivateDataPath, 'utf8');
    userPrivateData = JSON.parse(userPrivateContent);
    console.log('User private data read successfully:', userPrivateData);
  } catch (error) {
    console.error('Error reading or parsing user private data file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  if (!userPrivateData.moderator) {
    console.log('User is not authorized as a moderator:', user.email);
    return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this profile.' });
  }

  const privateFolderPath = path.join(__dirname, 'users', 'private');

  let privateFilePath;
  let authorFilePath;

  try {
    const files = await fs.promises.readdir(privateFolderPath);
    console.log('Private folder files read successfully:', files);

    for (const file of files) {
      if (file.endsWith('.json')) {
        const filePath = path.join(privateFolderPath, file);
        const fileContent = await fs.promises.readFile(filePath, 'utf8');
        const profile = JSON.parse(fileContent);

        console.log(`Checking profile with ID ${profile.id} against provided ID ${id}`);

        if (`${profile.id}` === `${id}`) {
          authorFilePath = path.join(__dirname, 'data', 'authors', `${profile.username}.json`);
          privateFilePath = filePath;
          console.log('Match found. Author file path:', authorFilePath);
          console.log('Private file path:', privateFilePath);
          break;
        }
      }
    }

    if (!authorFilePath || !privateFilePath) {
      console.log('Profile not found for ID:', id);
      return res.status(404).json({ message: 'Profile not found.' });
    }

    const authorData = await fs.promises.readFile(authorFilePath, 'utf8');
    let authorProfile = JSON.parse(authorData);

    console.log('Author profile before update:', authorProfile);

    authorProfile.bughunter = !authorProfile.bughunter;

    await fs.promises.writeFile(authorFilePath, JSON.stringify(authorProfile, null, 2), 'utf8');
    console.log('Author profile updated as bughunter:', authorProfile);

    const privateData = await fs.promises.readFile(privateFilePath, 'utf8');
    let privateProfile = JSON.parse(privateData);

    console.log('Private profile before update:', privateProfile);

    privateProfile.bughunter = authorProfile.bughunter;

    await fs.promises.writeFile(privateFilePath, JSON.stringify(privateProfile, null, 2), 'utf8');
    console.log('Private profile updated as bughunter:', privateProfile);

    res.json({ message: 'Profiles marked as bughunter.' });
  } catch (error) {
    console.error('Error updating profiles:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
});



app.delete('/moderator-promo-author/:moderator/:id/:owner/:token', async (req, res) => {
  const { moderator, id, owner, token } = req.params;

  if (!token) {
    console.log('No token found in request parameters');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensJson;
  try {
    const tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
    tokensJson = JSON.parse(tokensContent);
    console.log('Tokens file read successfully:', tokensJson);
  } catch (error) {
    console.error('Error reading or parsing tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  console.log('Found user:', user);

  const userPrivateDataPath = path.join(__dirname, 'users', 'private', `${user.email}.json`);

  let userPrivateData;
  try {
    const userPrivateContent = await fs.promises.readFile(userPrivateDataPath, 'utf8');
    userPrivateData = JSON.parse(userPrivateContent);
    console.log('User private data read successfully:', userPrivateData);
  } catch (error) {
    console.error('Error reading or parsing user private data file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  if (!userPrivateData.moderator) {
    console.log('User is not authorized as a moderator:', user.email);
    return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this profile.' });
  }

  const privateFolderPath = path.join(__dirname, 'users', 'private');

  let privateFilePath;
  let authorFilePath;

  try {
    const files = await fs.promises.readdir(privateFolderPath);
    console.log('Private folder files read successfully:', files);

    for (const file of files) {
      if (file.endsWith('.json')) {
        const filePath = path.join(privateFolderPath, file);
        const fileContent = await fs.promises.readFile(filePath, 'utf8');
        const profile = JSON.parse(fileContent);

        console.log(`Checking profile with ID ${profile.id} against provided ID ${id}`);

        if (`${profile.id}` === `${id}`) {
          authorFilePath = path.join(__dirname, 'data', 'authors', `${profile.username}.json`);
          privateFilePath = filePath;
          console.log('Match found. Author file path:', authorFilePath);
          console.log('Private file path:', privateFilePath);
          break;
        }
      }
    }

    if (!authorFilePath || !privateFilePath) {
      console.log('Profile not found for ID:', id);
      return res.status(404).json({ message: 'Profile not found.' });
    }

    const authorData = await fs.promises.readFile(authorFilePath, 'utf8');
    let authorProfile = JSON.parse(authorData);

    console.log('Author profile before update:', authorProfile);

    authorProfile.promoted = !authorProfile.promoted;

    await fs.promises.writeFile(authorFilePath, JSON.stringify(authorProfile, null, 2), 'utf8');
    console.log('Author profile updated as promoted:', authorProfile);

    const privateData = await fs.promises.readFile(privateFilePath, 'utf8');
    let privateProfile = JSON.parse(privateData);

    console.log('Private profile before update:', privateProfile);

    privateProfile.promoted = authorProfile.promoted;

    await fs.promises.writeFile(privateFilePath, JSON.stringify(privateProfile, null, 2), 'utf8');
    console.log('Private profile updated as promoted:', privateProfile);

    res.json({ message: 'Profiles marked as promoted.' });
  } catch (error) {
    console.error('Error updating profiles:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
});



app.delete('/admin-moderator-author/:moderator/:id/:owner/:token', async (req, res) => {
  const { moderator, id, owner, token } = req.params;

  if (!token) {
    console.log('No token found in request parameters');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensJson;
  try {
    const tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
    tokensJson = JSON.parse(tokensContent);
    console.log('Tokens file read successfully:', tokensJson);
  } catch (error) {
    console.error('Error reading or parsing tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  console.log('Found user:', user);

  const userPrivateDataPath = path.join(__dirname, 'users', 'private', `${user.email}.json`);

  let userPrivateData;
  try {
    const userPrivateContent = await fs.promises.readFile(userPrivateDataPath, 'utf8');
    userPrivateData = JSON.parse(userPrivateContent);
    console.log('User private data read successfully:', userPrivateData);
  } catch (error) {
    console.error('Error reading or parsing user private data file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  if (!userPrivateData.admin) {
    console.log('User is not authorized as a moderator:', user.email);
    return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this profile.' });
  }

  const privateFolderPath = path.join(__dirname, 'users', 'private');

  let privateFilePath;
  let authorFilePath;

  try {
    const files = await fs.promises.readdir(privateFolderPath);
    console.log('Private folder files read successfully:', files);

    for (const file of files) {
      if (file.endsWith('.json')) {
        const filePath = path.join(privateFolderPath, file);
        const fileContent = await fs.promises.readFile(filePath, 'utf8');
        const profile = JSON.parse(fileContent);

        console.log(`Checking profile with ID ${profile.id} against provided ID ${id}`);

        if (`${profile.id}` === `${id}`) {
          authorFilePath = path.join(__dirname, 'data', 'authors', `${profile.username}.json`);
          privateFilePath = filePath;
          console.log('Match found. Author file path:', authorFilePath);
          console.log('Private file path:', privateFilePath);
          break;
        }
      }
    }

    if (!authorFilePath || !privateFilePath) {
      console.log('Profile not found for ID:', id);
      return res.status(404).json({ message: 'Profile not found.' });
    }

    const authorData = await fs.promises.readFile(authorFilePath, 'utf8');
    let authorProfile = JSON.parse(authorData);

    console.log('Author profile before update:', authorProfile);

    authorProfile.moderator = !authorProfile.moderator;

    await fs.promises.writeFile(authorFilePath, JSON.stringify(authorProfile, null, 2), 'utf8');
    console.log('Author profile updated as moderator:', authorProfile);

    const privateData = await fs.promises.readFile(privateFilePath, 'utf8');
    let privateProfile = JSON.parse(privateData);

    console.log('Private profile before update:', privateProfile);

    privateProfile.moderator = authorProfile.moderator;

    await fs.promises.writeFile(privateFilePath, JSON.stringify(privateProfile, null, 2), 'utf8');
    console.log('Private profile updated as moderator:', privateProfile);

    res.json({ message: 'Profiles marked as moderator.' });
  } catch (error) {
    console.error('Error updating profiles:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }
});

























app.post('/edit-data', (req, res) => {
  console.log('Received POST request to /edit-data');

  const { editData, editData2 } = req.body;

  const updateOrCreateData = (filePath, dataName, dataValue, callback) => {
      console.log(`Updating data: ${filePath} - ${dataName} - ${dataValue}`);

      const filePathFull = path.join(__dirname, 'data', 'authors', `${filePath}.json`);

      // Check if the directory exists, create if it doesn't
      const directory = path.dirname(filePathFull);
      if (!fs.existsSync(directory)) {
          fs.mkdirSync(directory, { recursive: true });
      }

      fs.readFile(filePathFull, 'utf8', (err, data) => {
          let fileData = {};
          if (!err) {
              try {
                  fileData = JSON.parse(data);
              } catch (parseErr) {
                  return callback(parseErr);
              }
          }

          // Update or create the data value
          fileData[dataName] = dataValue;

          // Write the updated data back to the file
          fs.writeFile(filePathFull, JSON.stringify(fileData, null, 2), 'utf8', (writeErr) => {
              if (writeErr) {
                  return callback(writeErr);
              }
              callback(null);
          });
      });
  };

  // Update or create both editData and editData2
  updateOrCreateData(editData.filePath, editData.dataName, editData.dataValue, (err) => {
      if (err) {
          console.error('Error updating display name:', err);
          return res.status(500).send('Error updating display name');
      }
      console.log('Display name updated successfully');

      updateOrCreateData(editData2.filePath, editData2.dataName, editData2.dataValue, (err) => {
          if (err) {
              console.error('Error updating profile picture:', err);
              return res.status(500).send('Error updating profile picture');
          }
          console.log('Profile picture updated successfully');

          // Send response back to the client after both updates are done
          res.json({ message: 'Edit successful' });
      });
  });
});

// POST endpoint to handle form submission and CAPTCHA verification
app.post('/anti-bot', async (req, res) => {
  const captchaResponse = req.body['h-captcha-response'];
  const secretKey = 'a1709015-a704-4a60-b17f-f3383b6e2238';

  try {
      // Verify CAPTCHA response with hCaptcha API
      const verificationResponse = await axios.post('https://hcaptcha.com/siteverify', {
          secret: secretKey,
          response: captchaResponse
      });

      // Check if verification was successful
      if (verificationResponse.data.success) {
          // CAPTCHA was successfully verified, proceed with form submission handling
          // Handle form submission logic here...
          res.send('Form submitted successfully!');
      } else {
          // CAPTCHA verification failed
          res.status(400).send('CAPTCHA verification failed.');
      }
  } catch (error) {
      console.error('Error verifying CAPTCHA:', error);
      res.status(500).send('Error verifying CAPTCHA.');
  }
});

// Route to serve HTML page with a list of authors
app.get('/authors', async (req, res) => {
  const directoryPath = path.join(__dirname, 'data', 'authors');

  try {
    const files = await fs.promises.readdir(directoryPath);
    const authors = [];

    for (const file of files) {
      const filePath = path.join(directoryPath, file);
      const data = await fs.promises.readFile(filePath);
      const userData = JSON.parse(data);
      authors.push(userData);
    }

    const htmlData = await fs.promises.readFile(path.join(__dirname, 'author_list.html'), 'utf8');
    const modifiedHtml = htmlData.replace('{{authorsJSON}}', JSON.stringify(authors));

    res.setHeader('Content-Type', 'text/html');
    res.send(modifiedHtml);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Route to fetch authors data in JSON format
app.get('/authors-fetch', async (req, res) => {
  const directoryPath = path.join(__dirname, 'data', 'authors');

  try {
      const files = await fs.promises.readdir(directoryPath);
      const authors = [];

      for (const file of files) {
          const filePath = path.join(directoryPath, file);
          const data = await fs.promises.readFile(filePath);
          const userData = JSON.parse(data);
          authors.push(userData);
      }

      res.json(authors);
  } catch (error) {
      console.error('Error:', error);
      res.status(500).send('Internal Server Error');
  }
});

app.get('/author/:username', (req, res) => {
  const username = req.params.username;
  const filePath = path.join(__dirname, 'data', 'authors', `${username}.json`);
  
  // Read the JSON file
  fs.readFile(filePath, (err, data) => {
      if (err) {
          return res.status(404).send('User not found');
      }
      const userData = JSON.parse(data);
      
      // Send the HTML page along with user data
      res.sendFile(path.join(__dirname, 'author_profile.html'), { userData });
  });
});













app.get('/profiles-fetch', async (req, res) => {
  const profileDir = path.join(__dirname, 'data', 'profiles');

  async function getAllOP5Files5(dir) {
    let files = [];
    const items = await fs2.readdir(dir, { withFileTypes: true });

    for (const item of items) {
      if (item.name.includes('private')) continue;

      const fullPath = path.join(dir, item.name);
      if (item.isDirectory()) {
        files = files.concat(await getAllOP5Files5(fullPath));
      } else if (path.extname(item.name) === '.op5') {
        files.push(fullPath);
      }
    }

    return files;
  }

  try {
    const allJSONFiles = await getAllOP5Files5(profileDir);
    const profiles = await Promise.all(allJSONFiles.map(async filePath => {
      const data = await fs2.readFile(filePath, 'utf-8');
      return JSON.parse(data);
    }));
    
    res.json(profiles);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Internal Server Error');
  }
});


















app.get('/profiles-fetch-author/:username', async (req, res) => {
  const authorUsername = req.params.username; // Extract the username from the URL

  // Define the path for the author's profile directory
  const authorProfileDir = path.join(__dirname, 'data', 'authors', `${authorUsername}.json`);

  try {
    // Read the author's profile data to get the .id
    const authorData = fs.readFileSync(authorProfileDir);
    const authorId = JSON.parse(authorData).id;

    // Define the path for the profile directory based on the author's ID
    const profileDir = path.join(__dirname, 'data', 'profiles', `${authorId}`, 'public');

    // Read the list of files in the profile directory
    const files = fs.readdirSync(profileDir);

    // Create an array to hold the profiles
    const profiles = [];

    // Populate the profiles array
    files.forEach(file => {
      const filePath = path.join(profileDir, file);
      const profileData = fs.readFileSync(filePath);
      const profile = JSON.parse(profileData);
      profiles.push(profile);
    });

    // Return the profiles along with the total count
    const totalMatchingProfiles = profiles.length;
    res.json({ totalMatchingProfiles, profiles });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Route to serve HTML page with a list of authors
app.get('/profiles', async (req, res) => {
  try {
    const htmlData = await fs.promises.readFile(path.join(__dirname, 'character_profile_list.html'), 'utf8');
    res.setHeader('Content-Type', 'text/html');
    res.send(htmlData);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Internal Server Error');
  }
});

const getAllJSONFiles = (dir, fileList = []) => {
  const files = fs.readdirSync(dir);
  
  files.forEach(file => {
    const filePath = path.join(dir, file);
    if (fs.statSync(filePath).isDirectory()) {
      fileList = getAllJSONFiles(filePath, fileList);
    } else if (file.endsWith('.json')) {
      fileList.push(filePath);
    }
  });
  
  return fileList;
};

const getAllOP5Files = (dirPath, arrayOfFiles) => {
  const files = fs.readdirSync(dirPath);
  arrayOfFiles = arrayOfFiles || [];
  
  files.forEach(file => {
      const filePath = path.join(dirPath, file);
      if (fs.statSync(filePath).isDirectory()) {
          // Skip backups and deleted directories
          if (file !== 'backups' && file !== 'deleted') {
              arrayOfFiles = getAllOP5Files(filePath, arrayOfFiles);
          }
      } else {
          if (filePath.endsWith('.op5')) {
              arrayOfFiles.push(filePath);
          }
      }
  });
  
  return arrayOfFiles;
};





















// Endpoint to handle profile deletion
app.delete('/delete-profile/:id/:token', async (req, res) => {
  const profileId = req.params.id; // Extract profile ID from route parameter
  const token = req.params.token; // Extract token from route parameter
  console.log('Fetching profiles for id:', profileId);

  if (!token) {
      console.log('No token found in request');
      return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  // Define path for tokens file
  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');
  console.log('Tokens file path:', tokensFilePath);

  let tokensContent;
  try {
      tokensContent = await fs2.readFile(tokensFilePath, 'utf8');
      console.log('Tokens file content:', tokensContent);
  } catch (error) {
      console.error('Error reading tokens file:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  let tokensJson;
  try {
      tokensJson = JSON.parse(tokensContent);
      console.log('Parsed tokens JSON:', tokensJson);
  } catch (error) {
      console.error('Error parsing tokens JSON:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  // Find user with matching token
  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
      console.log('User not found for token:', token);
      return res.status(401).json({ message: 'User not found.' });
  }
  
  // Ensure the profile ID is valid (sanity check)
  if (!profileId) {
    return res.status(400).json({ error: 'Profile ID not provided.' });
  }

  const userid = user.id

  // Define paths for source (current) and target (.deleted) files
  const sourceFilePath = path.join(profilesFolder, `${userid}`, 'private', `${profileId}.op5`);
  const targetFolderPath = path.join(profilesFolder, `${userid}`, 'private', 'deleted');

  // Create .deleted folder if it doesn't exist
  if (!fs.existsSync(targetFolderPath)) {
    try {
      fs.mkdirSync(targetFolderPath, { recursive: true });
    } catch (err) {
      console.error('Failed to create .deleted folder:', err);
      return res.status(500).json({ error: 'Failed to delete profile.' });
    }
  }

  // Move file to .deleted folder
  const targetFilePath = path.join(targetFolderPath, `${profileId}.op5`);
  fs.rename(sourceFilePath, targetFilePath, (err) => {
    if (err) {
      console.error('Error moving file:', err);
      return res.status(500).json({ error: 'Failed to move profile to .deleted folder.' });
    }

    console.log('Profile moved to .deleted folder:', profileId);
    res.json({ message: 'Profile deleted and moved to .deleted folder.' });
  });
});















// Endpoint to handle profile deletion
app.delete('/restore-profile/:id/:token', async (req, res) => {
  const profileId = req.params.id; // Extract profile ID from route parameter
  const token = req.params.token; // Extract token from route parameter
  console.log('Fetching profiles for id:', profileId);

  if (!token) {
      console.log('No token found in request');
      return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  // Define path for tokens file
  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');
  console.log('Tokens file path:', tokensFilePath);

  let tokensContent;
  try {
      tokensContent = await fs2.readFile(tokensFilePath, 'utf8');
      console.log('Tokens file content:', tokensContent);
  } catch (error) {
      console.error('Error reading tokens file:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  let tokensJson;
  try {
      tokensJson = JSON.parse(tokensContent);
      console.log('Parsed tokens JSON:', tokensJson);
  } catch (error) {
      console.error('Error parsing tokens JSON:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  // Find user with matching token
  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
      console.log('User not found for token:', token);
      return res.status(401).json({ message: 'User not found.' });
  }
  
  // Ensure the profile ID is valid (sanity check)
  if (!profileId) {
    return res.status(400).json({ error: 'Profile ID not provided.' });
  }

  const userid = user.id

  // Define paths for source (current) and target (.deleted) files
  const sourceFilePath = path.join(profilesFolder, `${userid}`, 'private', 'deleted', `${profileId}.op5`);
  const targetFolderPath = path.join(profilesFolder, `${userid}`, 'private');

  // Create .deleted folder if it doesn't exist
  if (!fs.existsSync(targetFolderPath)) {
    try {
      fs.mkdirSync(targetFolderPath, { recursive: true });
    } catch (err) {
      console.error('Failed to create .deleted folder:', err);
      return res.status(500).json({ error: 'Failed to restore profile.' });
    }
  }

  // Move file to .deleted folder
  const targetFilePath = path.join(targetFolderPath, `${profileId}.op5`);
  fs.rename(sourceFilePath, targetFilePath, (err) => {
    if (err) {
      console.error('Error moving file:', err);
      return res.status(500).json({ error: 'Failed to move the profile.' });
    }

    console.log('Profile restored to private folder:', profileId);
    res.json({ message: 'Profile restored and moved to .deleted folder.' });
  });
});













// Endpoint to handle profile deletion
app.delete('/restore-backup-profile/:id/:version/:token', async (req, res) => {
  const profileId = req.params.id;
  const version = req.params.version;
  const token = req.params.token;
  console.log('Fetching profiles for id:', profileId);

  if (!token) {
      console.log('No token found in request');
      return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  // Define path for tokens file
  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');
  console.log('Tokens file path:', tokensFilePath);

  let tokensContent;
  try {
      tokensContent = await fs2.readFile(tokensFilePath, 'utf8');
      console.log('Tokens file content:', tokensContent);
  } catch (error) {
      console.error('Error reading tokens file:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  let tokensJson;
  try {
      tokensJson = JSON.parse(tokensContent);
      console.log('Parsed tokens JSON:', tokensJson);
  } catch (error) {
      console.error('Error parsing tokens JSON:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  // Find user with matching token
  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
      console.log('User not found for token:', token);
      return res.status(401).json({ message: 'User not found.' });
  }

  // Ensure the profile ID is valid (sanity check)
  if (!profileId) {
    return res.status(400).json({ error: 'Profile ID not provided.' });
  }

  const userid = user.id;

  // Define paths for source (current) and target (.deleted) files
  const sourceFilePath = path.join(profilesFolder, `${userid}`, 'private', 'backups', `${profileId}`, `${profileId}_${version}.op5`);
  const targetFolderPath = path.join(profilesFolder, `${userid}`, 'private');

  // Create .deleted folder if it doesn't exist
  if (!fs.existsSync(targetFolderPath)) {
    try {
      fs.mkdirSync(targetFolderPath, { recursive: true });
    } catch (err) {
      console.error('Failed to create .deleted folder:', err);
      return res.status(500).json({ error: 'Failed to create .deleted folder.' });
    }
  }

  // Move file to private folder and rename it to the profile ID
  const targetFilePath = path.join(targetFolderPath, `${profileId}.op5`);
  fs.rename(sourceFilePath, targetFilePath, async (err) => {
    if (err) {
      console.error('Error moving file:', err);
      return res.status(500).json({ error: 'Failed to move the profile.' });
    }

    console.log('Profile restored to private folder:', profileId);

    // Now update the visibility value to "Private"
    try {
      const fileContent = await fs2.readFile(targetFilePath, 'utf8');
      const profileData = JSON.parse(fileContent);

      // Update visibility to "Private"
      profileData.visibility = 'private';

      // Write updated data back to file
      await fs2.writeFile(targetFilePath, JSON.stringify(profileData, null, 2));
      console.log('Profile visibility updated to Private.');

      res.json({ message: 'Profile restored and visibility updated to Private.' });
    } catch (error) {
      console.error('Error updating profile visibility:', error);
      return res.status(500).json({ error: 'Failed to update profile visibility.' });
    }
  });
});










// Endpoint to handle saving author data
app.post('/authors-edit/:id/:authorid/:token', async (req, res) => {
  const id = req.params.id;
  const authorid = req.params.authorid;
  const token = req.params.token;
  const { data } = req.body;

  console.log('Saving author data for id:', id);

  if (!token) {
    console.log('No token found');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  if (!data) {
    console.log('No data provided');
    return res.status(400).json({ message: 'No data provided' });
  }

  console.log('Received token:', token);
  console.log('Received data:', data);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensContent;
  try {
    tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
  } catch (error) {
    console.error('Error reading tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  let tokensJson;
  try {
    tokensJson = JSON.parse(tokensContent);
  } catch (error) {
    console.error('Error parsing tokens JSON:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found' });
  }

  const userid = `${user.id}`;
  if (id === userid) {
    console.log('Found user with matching token:', user);
    try {
      const profileDir = path.join(__dirname, 'data', 'authors');
      const authorFilePath = path.join(profileDir, `${data.username}.json`); // Ensure this matches your data structure

      // Check if `data.id` matches the `id` from URL
      if (id === authorid) {
        let existingData;
        try {
          existingData = JSON.parse(await fs.promises.readFile(authorFilePath, 'utf8'));
        } catch (error) {
          if (error.code === 'ENOENT') {
            existingData = {}; // If file does not exist, initialize with an empty object
          } else {
            console.error('Error reading existing author data:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
          }
        }

        // Merge new data with existing data
        const updatedData = { ...existingData, ...data };

        // Ensure directory exists
        await fs.promises.mkdir(profileDir, { recursive: true });

        // Write the updated data to the file
        await fs.promises.writeFile(authorFilePath, JSON.stringify(updatedData, null, 2), 'utf8');
        console.log('Author profile updated:', updatedData);

        res.json({ message: 'Author profile updated successfully' });
      } else {
        res.status(403).json({ message: 'Forbidden: User ID mismatch' });
      }
    } catch (error) {
      console.error('Error updating author profile:', error);
      res.status(500).json({ message: 'Internal Server Error' });
    }
  } else {
    res.status(403).json({ message: 'Forbidden: User ID mismatch' });
  }
});






















app.get('/profiles-edit/:id/:token', async (req, res) => {
  const id = req.params.id; // Extract id from route parameter
  const token = req.params.token; // Extract token from route parameter
  console.log('Fetching profiles for id:', id);

  if (!token) {
      console.log('No token found in cookies');
      return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token from cookies:', token);

  // Read tokens.json
  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');
  //console.log('Tokens file path:', tokensFilePath);

  let tokensContent;
  try {
      tokensContent = await fs2.readFile(tokensFilePath, 'utf8');
      console.log('Tokens file content:', tokensContent);
  } catch (error) {
      console.error('Error reading tokens file:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  let tokensJson;
  try {
      tokensJson = JSON.parse(tokensContent);
      console.log('Parsed tokens JSON:', tokensJson);
  } catch (error) {
      console.error('Error parsing tokens JSON:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  // Find user with matching token
  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
      console.log('User not found for token:', token);
      return res.status(401).json({ message: 'User not found.' });
  }
  
  const userid = user.id
  if (id == userid) {
    console.log('Found user with matching token:', user);
    try {
      const profileDir = path.join(__dirname, 'data', 'profiles', `${userid}`, 'private');
      const profileDir2 = path.join(__dirname, 'data', 'profiles', `${userid}`, 'public');
  
      // Get all OP5 files from both directories
      const allOP5Files = [...getAllOP5Files(profileDir), ...getAllOP5Files(profileDir2)];
  
      // Read and parse each profile file
      const profiles = allOP5Files.map(filePath => {
        try {
          const data = fs.readFileSync(filePath, 'utf8');
          return JSON.parse(data);
        } catch (error) {
          console.error('Error parsing file:', filePath, error);
          return null; // or handle error as needed
        }
      }).filter(profile => profile);
  
      // Send the profiles as JSON response
      res.json(profiles);
    } catch (error) {
      console.error('Error:', error);
      res.status(500).send('Internal Server Error');
    }
  }
});

app.get('/profiles-edit-2/:id/:token', async (req, res) => {
  const id = req.params.id; // Extract id from route parameter
  const token = req.params.token; // Extract token from route parameter
  console.log('Fetching profiles for id:', id);

  if (!token) {
      console.log('No token found in cookies');
      return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token from cookies:', token);

  // Read tokens.json
  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');
  console.log('Tokens file path:', tokensFilePath);

  let tokensContent;
  try {
      tokensContent = await fs2.readFile(tokensFilePath, 'utf8');
      console.log('Tokens file content:', tokensContent);
  } catch (error) {
      console.error('Error reading tokens file:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  let tokensJson;
  try {
      tokensJson = JSON.parse(tokensContent);
      console.log('Parsed tokens JSON:', tokensJson);
  } catch (error) {
      console.error('Error parsing tokens JSON:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  // Find user with matching token
  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
      console.log('User not found for token:', token);
      return res.status(401).json({ message: 'User not found.' });
  }
  
  const userid = user.id
  if (id == userid) {
    console.log('Found user with matching token:', user);
    try {
        const profileDir = path.join(__dirname, 'data', 'profiles', `${userid}`, 'private', 'deleted');
        const allOP5Files = getAllOP5Files(profileDir);

        // Read and parse each profile file
        const profiles = allOP5Files.map(filePath => {
            try {
                const data = fs.readFileSync(filePath, 'utf8');
                return JSON.parse(data);
            } catch (error) {
                console.error('Error parsing file:', filePath, error);
                return null; // or handle error as needed
            }
        }).filter(profile => profile);

        console.log('Fetched profiles:', profiles);
        res.json(profiles);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Internal Server Error');
    }
  }
});

app.get('/profiles-edit-3/:id/:token', async (req, res) => {
  const id = req.params.id; // Extract id from route parameter
  const token = req.params.token; // Extract token from route parameter
  console.log('Fetching profiles for id:', id);

  if (!token) {
      console.log('No token found in cookies');
      return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token from cookies:', token);

  // Read tokens.json
  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');
  console.log('Tokens file path:', tokensFilePath);

  let tokensContent;
  try {
      tokensContent = await fs2.readFile(tokensFilePath, 'utf8');
      console.log('Tokens file content:', tokensContent);
  } catch (error) {
      console.error('Error reading tokens file:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  let tokensJson;
  try {
      tokensJson = JSON.parse(tokensContent);
      console.log('Parsed tokens JSON:', tokensJson);
  } catch (error) {
      console.error('Error parsing tokens JSON:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
  }

  // Find user with matching token
  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
      console.log('User not found for token:', token);
      return res.status(401).json({ message: 'User not found.' });
  }
  
  const userid = user.id
  if (id == userid) {
    console.log('Found user with matching token:', user);
    try {
        const profileDir = path.join(__dirname, 'data', 'profiles', `${userid}`, 'private', 'backups');
        const allOP5Files = getAllOP5Files(profileDir);

        // Read and parse each profile file
        const profiles = allOP5Files.map(filePath => {
            try {
                const data = fs.readFileSync(filePath, 'utf8');
                return JSON.parse(data);
            } catch (error) {
                console.error('Error parsing file:', filePath, error);
                return null; // or handle error as needed
            }
        }).filter(profile => profile);

        console.log('Fetched profiles:', profiles);
        res.json(profiles);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Internal Server Error');
    }
  }
});

app.get('/profiles-edit-4/:id', async (req, res) => {
  const id = req.params.id; // Extract id from route parameter
  console.log('Fetching profiles for id:', id);

  const userid = id
  if (id == userid) {
    try {
        const profileDir = path.join(__dirname, 'data', 'profiles', `${userid}`, 'public');
        const allOP5Files = getAllOP5Files(profileDir);

        // Read and parse each profile file
        const profiles = allOP5Files.map(filePath => {
            try {
                const data = fs.readFileSync(filePath, 'utf8');
                return JSON.parse(data);
            } catch (error) {
                console.error('Error parsing file:', filePath, error);
                return null; // or handle error as needed
            }
        }).filter(profile => profile);

        console.log('Fetched profiles:', profiles);
        res.json(profiles);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Internal Server Error');
    }
  }
});
















// Helper function to get all .op5 files, excluding directories starting with "backups" or "deleted"
function getAllOP5Files_download(dir) {
  let results = [];
  const list = fs.readdirSync(dir);

  list.forEach(file => {
    file = path.resolve(dir, file);
    const stat = fs.statSync(file);

    if (stat && stat.isDirectory()) {
      // Exclude directories starting with "backups" or "deleted"
      const dirName = path.basename(file);
      if (dirName.startsWith('backups') || dirName.startsWith('deleted')) {
        console.log(`Skipping directory: ${file}`);
        return; // Skip this directory
      }
      results = results.concat(getAllOP5Files_download(file)); // Recursively search within the directory
    } else if (file.endsWith('.op5')) {
      results.push(file); // Add .op5 files to the results
    }
  });

  return results;
}

app.get('/download-profile/:author/:id/:token', async (req, res) => {
  const id = req.params.id; // Extract id from route parameter
  const author = req.params.author; // Extract author from route parameter
  const token = req.params.token; // Extract token from route parameter
  console.log('Fetching profiles for id:', id);

  if (!token) {
    console.log('No token found');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  // Read tokens.json
  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensContent;
  try {
    tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
    console.log('Tokens file content:', tokensContent);
  } catch (error) {
    console.error('Error reading tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  let tokensJson;
  try {
    tokensJson = JSON.parse(tokensContent);
    console.log('Parsed tokens JSON:', tokensJson);
  } catch (error) {
    console.error('Error parsing tokens JSON:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  // Find user with matching token
  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  const userid = user.id;
  if (`${author}` === `${userid}`) {
    console.log('Found user with matching token:', user);
    try {
      const profileDir = path.join(__dirname, 'data', 'profiles', `${userid}`);
      const allOP5Files = getAllOP5Files_download(profileDir);

      if (allOP5Files.length > 0) {
        const filePath = allOP5Files.find(file => path.basename(file, '.op5') === id) || allOP5Files[0]; // Find specific file or fallback to first file
        console.log('Sending file:', filePath);
        res.download(filePath, `${id}.op5`); // Specify the download name
      } else {
        res.status(404).json({ message: 'No .op5 files found.' });
      }
    } catch (error) {
      console.error('Error:', error);
      res.status(500).send('Internal Server Error');
    }
  } else {
    res.status(403).json({ message: 'Forbidden' });
  }
});





































// Configure multer for file storage and filtering
const upload = multer({
  // Define a storage configuration
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      const uploadDir = 'uploads/';
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir); // Specify the directory to save files
    },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname)); // Define file naming
    }
  }),
  limits: { fileSize: 10 * 1024 * 1024 }, // Set file size limit to 10MB
  fileFilter: (req, file, cb) => {
    if (path.extname(file.originalname) === '.op5') {
      cb(null, true); // Accept the file
    } else {
      cb(new Error('Invalid file type, only .op5 files are allowed'), false); // Reject the file
    }
  }
});

// Function to modify file content
function modifyFileContent(content, newId, newUrl, newUrl2, authoridnew, authornamenew) {
  let json;
  try {
    json = JSON.parse(content);
  } catch (error) {
    throw new Error('Failed to parse file content');
  }

  // Delete existing fields
  delete json['url'];
  delete json['url2'];
  delete json['owner'];
  delete json['owner2'];
  delete json['visibility'];
  delete json['promoted'];
  delete json['verified'];

  // Replace with new values
  json['id'] = newId;
  json['url'] = newUrl;
  json['url2'] = newUrl2;
  json['owner'] = authoridnew;
  json['owner2'] = authornamenew;
  json['visibility'] = "private";

  // Convert back to JSON string and return
  return JSON.stringify(json, null, 2);
}

// Route to handle file upload
app.post('/upload-profile/:usernameid/:username/:token', upload.single('file'), async (req, res) => {
  const usernameid = req.params.usernameid;
  const username = req.params.username;
  const token = req.params.token;
  const file = req.file;

  if (!file) {
    console.error('No file uploaded');
    return res.status(400).json({ message: 'No file uploaded' });
  }

  if (!file.path) {
    console.error('File path is undefined');
    return res.status(400).json({ message: 'File path is undefined' });
  }

  console.log('Uploading file for usernameid:', usernameid);
  console.log('File path:', file.path); // Debugging: Log file path

  if (!token) {
    console.log('No token found');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  // Read tokens.json
  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

  let tokensContent;
  try {
    tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
  } catch (error) {
    console.error('Error reading tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  let tokensJson;
  try {
    tokensJson = JSON.parse(tokensContent);
  } catch (error) {
    console.error('Error parsing tokens JSON:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  // Find user with matching token
  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  const userid = user.id;
  if (`${usernameid}` === `${userid}`) {
    console.log('Found user with matching token:', user);

    // Read user data from JSON file
    const userFilePath = path.join(__dirname, 'data', 'authors', `${username}.json`);
    let userData;
    try {
      const userFileContent = await fs.promises.readFile(userFilePath, 'utf8');
      userData = JSON.parse(userFileContent);
    } catch (error) {
      console.error('Error reading user data file:', error);
      return res.status(404).json({ message: 'User data not found' });
    }

    // Process and save the uploaded file
    try {
      const uploadDir = path.join(__dirname, 'data', 'profiles', `${userid}`, 'private');
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }

      const new_id = generate_global_id();
      const newFileName = `${new_id}.op5`;
      const filePath = path.join(uploadDir, newFileName);

      // Read the file content
      const content = fs.readFileSync(file.path, 'utf8');
      console.log('File content:', content); // Debugging: Log file content

      // Use values from the user data file for modification
      const newId = `${new_id}`;
      const newUrl = `${new_id}`;
      const newUrl2 = `${new_id}`;
      const authoridnew = userData.id;
      const authornamenew = userData.username;

      // Modify the file content
      const modifiedContent = modifyFileContent(content, newId, newUrl, newUrl2, authoridnew, authornamenew);

      // Save the modified content to the file
      fs.writeFileSync(filePath, modifiedContent);

      // Clean up the temporary file
      fs.unlinkSync(file.path);

      console.log('File uploaded and modified:', filePath);
      res.json({ message: 'File uploaded and modified successfully!' });
    } catch (error) {
      console.error('Error processing file:', error);
      res.status(500).send('Internal Server Error');
    }
  } else {
    res.status(403).json({ message: 'Forbidden' });
  }
});

// Error handler for multer
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    // Handle multer errors
    return res.status(400).json({ message: err.message });
  }
  // Handle other errors
  res.status(500).json({ message: 'Internal Server Error' });
});



















































// Endpoint to check if a profile file exists
app.post('/check-profile-exists/:id', (req, res) => {
    const { ownerId } = req.body; // Assuming the client sends the ownerId
    const { id: fileid } = req.params;

    const profileFilePath = path.join(__dirname, 'data', 'profiles', `${ownerId}`, `${fileid}.json`);

    console.log('Checking profile existence for ownerId:', ownerId, 'fileid:', fileid, 'filePath:', profileFilePath);

    // Check if the file exists
    fs.access(profileFilePath, fs.constants.F_OK, (err) => {
        if (err) {
            console.error('Error checking profile existence:', err);
            res.status(500).json({ error: 'Internal server error' }); // Server error response
        } else {
            console.log('Profile exists for ownerId:', ownerId, 'fileid:', fileid);
            res.json({ exists: true }); // File exists
        }
    });
});












app.post('/create-profile', (req, res) => {
  const { fileName, data } = req.body;
  const owner = data.owner.toString(); // Ensure owner is a string

  // Check if JSON data exists in the request
  if (!data) {
    return res.status(400).json({ error: 'No JSON data provided' });
  }

  // Validate required fields
  if (!fileName || !data.id) {
    return res.status(400).json({ error: 'Incomplete data provided' });
  }

  try {
    // Define paths
    const privateFolderPath = path.join(profilesFolder, owner, 'private');
    const privateFilePath = path.join(privateFolderPath, `${data.id}.op5`);
    const backupFolderPath = path.join(privateFolderPath, 'backups', `${data.id}`);
    const backupFilePath = path.join(backupFolderPath, `${data.id}_${data.profile_version}.op5`);

    console.log('owner:', owner);
    console.log('privateFolderPath:', privateFolderPath);
    console.log('privateFilePath:', privateFilePath);
    console.log('backupFolderPath:', backupFolderPath);
    console.log('backupFilePath:', backupFilePath);

    // Ensure the directories exist
    if (!fs.existsSync(profilesFolder)) {
      fs.mkdirSync(profilesFolder, { recursive: true });
    }
    if (!fs.existsSync(path.join(profilesFolder, owner))) {
      fs.mkdirSync(path.join(profilesFolder, owner), { recursive: true });
    }
    if (!fs.existsSync(privateFolderPath)) {
      fs.mkdirSync(privateFolderPath, { recursive: true });
    }

    // Check if privateFilePath is a directory
    if (fs.existsSync(privateFilePath) && fs.lstatSync(privateFilePath).isDirectory()) {
      return res.status(500).json({ error: 'File path is a directory, not a file' });
    }

    // Initialize an empty object to store existing data
    let existingData = {};

    // Read existing data if file exists
    if (fs.existsSync(privateFilePath)) {
      const existingDataString = fs.readFileSync(privateFilePath, 'utf8');
      existingData = JSON.parse(existingDataString);
    }

    // Overwrite existing data with new data
    const mergedData = { ...existingData, ...data };

    // Get current date and time in local timezone
    const today = new Date();
    const todayDate = today.toLocaleDateString('en-CA');
    const todayTime = today.toLocaleTimeString('en-GB', { hour12: false });

    // Get local timezone name
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

    // Set created date/time/zone if not already set
    if (!mergedData.createdDate) {
      mergedData.createdDate = todayDate;
      mergedData.createdTime = todayTime;
      mergedData.createdZone = timezone;
    }

    // Convert merged data to JSON string
    const mergedDataString = JSON.stringify(mergedData, null, 2);

    // Write merged data to file
    fs.writeFileSync(privateFilePath, mergedDataString, 'utf8');

    // Create backups folder if it doesn't exist
    if (!fs.existsSync(backupFolderPath)) {
      fs.mkdirSync(backupFolderPath, { recursive: true });
    }

    // Write backup data to file
    fs.writeFileSync(backupFilePath, mergedDataString, 'utf8');

    // Send success response
    res.status(200).json({ message: 'File created successfully' });
  } catch (error) {
    console.error('Error creating profile data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});











app.post('/save-profile', (req, res) => {
  const { fileName, data } = req.body;
  const owner = data.owner;

  // Check if JSON data exists in the request
  if (!data) {
    return res.status(400).json({ error: 'No JSON data provided' });
  }

  // Validate required fields
  if (!fileName || !data.id) {
    return res.status(400).json({ error: 'Incomplete data provided' });
  }

  try {
    // Define paths
    const publicFolderPath = path.join(profilesFolder, `${owner}`, 'public');
    const publicFilePath = path.join(publicFolderPath, `${data.id}.op5`);
    const privateFilePath = path.join(profilesFolder, `${owner}`, 'private', `${data.id}.op5`);
    const backupFolderPath = path.join(profilesFolder, `${owner}`, 'private', 'backups', `${data.id}`);
    const backupFilePath = path.join(backupFolderPath, `${data.id}_${data.profile_version}.op5`);

    // Create profiles folder if it doesn't exist
    if (!fs.existsSync(profilesFolder)) {
      fs.mkdirSync(profilesFolder, { recursive: true });
    }

    // Copy the file from the public folder to the private folder if it doesn't exist in private
    if (!fs.existsSync(privateFilePath)) {
      fs.copyFileSync(publicFilePath, privateFilePath);
    }

    // Initialize an empty object to store existing data
    let existingData = {};

    // Read existing data if file exists
    if (fs.existsSync(privateFilePath)) {
      const existingDataString = fs.readFileSync(privateFilePath, 'utf8');
      existingData = JSON.parse(existingDataString);
    }

    // Overwrite existing data with new data
    const mergedData = { ...existingData, ...data };

    // Get current date and time in local timezone
    const today = new Date();
    const todayDate = today.toLocaleDateString('en-CA');
    const todayTime = today.toLocaleTimeString('en-GB', { hour12: false });

    // Get local timezone name
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

    // Set created date/time/zone if not already set
    if (!mergedData.createdDate) {
      mergedData.createdDate = todayDate;
      mergedData.createdTime = todayTime;
      mergedData.createdZone = timezone;
    }

    // Convert merged data to JSON string
    const mergedDataString = JSON.stringify(mergedData, null, 2);

    // Write merged data to file
    fs.writeFileSync(privateFilePath, mergedDataString, 'utf8');

    // Check if profile version ends with a '00'
    if (data.profile_version.toString().endsWith('00')) {
      // Create backups folder if it doesn't exist
      if (!fs.existsSync(backupFolderPath)) {
        fs.mkdirSync(backupFolderPath, { recursive: true });
      }

      // Function to get the creation date of a file
      const getCreationDate = (filePath) => {
        const stats = fs.statSync(filePath);
        return stats.birthtimeMs; // Return creation time in milliseconds
      };

      // Get all backup files for the character
      const backupFiles = fs.readdirSync(backupFolderPath).filter(file => file.endsWith('.op5'));

      // Get full paths for sorting
      const backupFilesWithPath = backupFiles.map(file => ({
        path: path.join(backupFolderPath, file),
        creationDate: getCreationDate(path.join(backupFolderPath, file))
      }));

      // Sort files by creation date
      backupFilesWithPath.sort((a, b) => a.creationDate - b.creationDate);

      // If there are more than 10 files, delete the oldest one
      if (backupFilesWithPath.length >= 10) {
        const oldestBackup = backupFilesWithPath[0];
        fs.unlinkSync(oldestBackup.path);
        console.log(`Deleted oldest backup: ${oldestBackup.path}`);
      }

      // Write backup data to file
      fs.writeFileSync(backupFilePath, mergedDataString, 'utf8');
    }

    // Send success response
    res.status(200).json({ message: 'File saved successfully' });
  } catch (error) {
    console.error('Error saving profile data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});















app.post('/update-visibility-profile/:id/:owner/:token', async (req, res) => {
  const profileId = req.params.id;
  const profileOwner = req.params.owner;
  const token = req.params.token;

  if (!token) {
    console.log('No token found in request parameters');
    return res.status(401).json({ message: 'Unauthorized' });
  }

  console.log('Received token:', token);

  const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');
  
  let tokensJson;
  try {
    const tokensContent = await fs.promises.readFile(tokensFilePath, 'utf8');
    tokensJson = JSON.parse(tokensContent);
    console.log('Parsed tokens JSON:', tokensJson);
  } catch (error) {
    console.error('Error reading or parsing tokens file:', error);
    return res.status(500).json({ message: 'Internal Server Error' });
  }

  const user = Object.values(tokensJson).find(user => user.token === token);

  if (!user) {
    console.log('User not found for token:', token);
    return res.status(401).json({ message: 'User not found.' });
  }

  console.log('Found user:', user);

  const { fileName, data, visibility } = req.body;

  if (!data) {
    return res.status(400).json({ error: 'No JSON data provided' });
  }

  if (!fileName || !data.id) {
    return res.status(400).json({ error: 'Incomplete data provided' });
  }

  const visibilityPath = visibility === 'public' ? 'public' : 'private';
  const visibilityPath2 = visibility === 'public' ? 'private' : 'public';
  console.log('Requested visibility:', visibility);
  console.log('Visibility path:', visibilityPath);

  const profilesFolder = path.join(__dirname, 'data', 'profiles');
  const filePath = path.join(profilesFolder, profileOwner, visibilityPath2, `${data.id}.op5`);
  const backupFolderPath = path.join(profilesFolder, profileOwner, 'private', 'backups', data.id);
  const backupFilePath = path.join(backupFolderPath, `${data.id}_${data.profile_version}.op5`);

  try {
    // Ensure profiles and backup folders exist
    await fs.promises.mkdir(path.dirname(filePath), { recursive: true });
    await fs.promises.mkdir(path.dirname(backupFilePath), { recursive: true });

    // Read and merge existing data
    let existingData = {};
    if (fs.existsSync(filePath)) {
      const existingDataString = await fs.promises.readFile(filePath, 'utf8');
      existingData = JSON.parse(existingDataString);
    }

    const mergedData = { ...existingData, ...data };

    const today = new Date();
    const todayDate = today.toLocaleDateString('en-CA');
    const todayTime = today.toLocaleTimeString('en-GB', { hour12: false });
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

    if (!mergedData.createdDate) {
      mergedData.createdDate = todayDate;
      mergedData.createdTime = todayTime;
      mergedData.createdZone = timezone;
    }

    mergedData.visibility = visibility;
    
    const mergedDataString = JSON.stringify(mergedData, null, 2);
    await fs.promises.writeFile(filePath, mergedDataString, 'utf8');
    await fs.promises.writeFile(backupFilePath, mergedDataString, 'utf8');

    // Handle file visibility change
    const currentVisibilityPath = mergedData.visibility === 'public' ? 'private' : 'public';
    const sourceFilePath = path.join(profilesFolder, profileOwner, currentVisibilityPath, `${profileId}.op5`);
    const targetFilePath = path.join(profilesFolder, profileOwner, visibilityPath, `${profileId}.op5`);

    if (fs.existsSync(sourceFilePath)) {
      await fs.promises.rename(sourceFilePath, targetFilePath);
      console.log(`Profile visibility updated to ${visibility}:`, profileId);
      return res.json({ message: `Profile visibility updated to ${visibility}.` });
    } else {
      console.error('Source file does not exist:', sourceFilePath);
      return res.status(404).json({ error: 'File not found.' });
    }
  } catch (error) {
    console.error('Error handling profile update:', error);
    return res.status(500).json({ error: 'Failed to update profile visibility.' });
  }
});






const cookieParser = require('cookie-parser');

// Middleware to parse cookies
app.use(cookieParser());

// Function to read views from the file
const readViews = () => {
  try {
    const data = fs.readFileSync('views.txt', 'utf8');
    return JSON.parse(data);
  } catch (err) {
    return {};
  }
};

// Function to write views to the file
const writeViews = (views) => {
  fs.writeFileSync('views.txt', JSON.stringify(views, null, 2));
};

// Clean up views that are older than one hour
const cleanUpOldViews = (viewTimes, currentTime, oneHour) => {
  return viewTimes.filter(viewTime => currentTime - viewTime.time < oneHour);
};

app.get('/view/:id', (req, res) => {
  const profileId = req.params.id;
  const userId = req.cookies.userId || new Date().getTime().toString();
  res.cookie('userId', userId, { maxAge: 3600000, httpOnly: false }); // 1 hour expiration

  const views = readViews();
  const currentTime = Date.now();
  const oneHour = 3600000; // 1 hour in milliseconds

  if (!views[profileId]) {
    views[profileId] = {
      total: 0,
      recent: []
    };
  }

  // Clean up old views
  views[profileId].recent = cleanUpOldViews(views[profileId].recent, currentTime, oneHour);

  const recentView = views[profileId].recent.find(view => view.userId === userId && currentTime - view.time < oneHour);
  console.log(profileId)
  if (!recentView) {
    views[profileId].recent.push({ userId, time: currentTime });
    views[profileId].total += 1;
    writeViews(views);
    res.send(`Profile ${profileId} viewed at ${new Date(currentTime).toLocaleString()}. Total views: ${views[profileId].total}`);
  } else {
    res.send(`Profile ${profileId} has been viewed recently. Try again later. Total views: ${views[profileId].total}`);
  }
});

app.get('/views', (req, res) => {
  const views = readViews();
  res.json(views);
});





















// Endpoint to provide JSON data
app.get('/profile/json/:url', (req, res) => {
  const requestedUrl = req.params.url;
  const profileDir = path.join(__dirname, 'data', 'profiles');

  // Recursively search for JSON files in the profile directory
  const allJSONFiles = getAllJSONFiles(profileDir);

  // Find the JSON file with matching URL
  const matchingFile = allJSONFiles.find(filePath => {
    const data = fs.readFileSync(filePath);
    const userData = JSON.parse(data);
    
    // Check if either userData.url or userData.url2 exactly matches the requested URL
    return userData.url === requestedUrl || userData.url2 === requestedUrl;
  });

  if (!matchingFile) {
    return res.redirect('https://preview.openprofile.app/');
    //return res.status(404).json({ error: 'Profile not found' });
  }

  // Read the matching JSON file
  fs.readFile(matchingFile, (err, data) => {
    if (err) {
      return res.status(500).json({ error: 'Internal Server Error' });
    }
    const userData = JSON.parse(data);
    res.json(userData);
  });
});











// Endpoint to serve HTML content
app.get('/profile/:url', (req, res) => {
  const url = req.params.url;
  const profileDir = path.join(__dirname, 'data', 'profiles');

  // Read the HTML file to render
  fs.readFile(path.join(__dirname, 'character_profile.html'), 'utf8', (err, html) => {
    if (err) {
      return res.status(500).send('Internal Server Error');
    }
    res.send(html);
  });
});

// Middleware
app.use(bodyParser.json());

// Session setup
const secretKey = crypto.randomBytes(32).toString('hex');
app.use(session({
    secret: secretKey,
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 30 * 24 * 60 * 60 * 1000 } // 30 days in milliseconds
}));

// Middleware to check if the user is logged in
function checkLoggedIn(req, res, next) {
    if (req.session && req.session.user) {
        next(); // User is logged in, continue to the next middleware
    } else {
        res.status(401).json({ loggedIn: false }); // User is not logged in
    }
}

// Route to check login status
app.get('/check-login', (req, res) => {
  // Include the full URL in the response
  res.json({
      loggedIn: req.session.user ? true : false,
      userData: req.session.user ? req.session.user : null,
      url: req.url // Include the full URL in the response
  });
});

// Define the function to read public user data
async function readPublicUserData(filename) {
  try {
      const filePath = path.join(__dirname, 'data', 'authors', filename);
      const data = await fs.readFile(filePath);
      return JSON.parse(data);
  } catch (error) {
      // If file not found or any other error, return null
      return null;
  }
}

// Function to save session data to a file
function saveSessionData(sessionData) {
  const sessionsDir = path.join(__dirname, 'users', 'private', 'sessions');
  const sessionFilePath = path.join(sessionsDir, 'tokens.json');

  // Ensure the directory exists
  if (!fs.existsSync(sessionsDir)) {
    fs.mkdirSync(sessionsDir, { recursive: true });
  }

  // Read existing session data
  let existingSessions = {};
  if (fs.existsSync(sessionFilePath)) {
    const existingData = fs.readFileSync(sessionFilePath, 'utf8');
    existingSessions = JSON.parse(existingData);
  }

  // Add the new session data
  existingSessions[sessionData.id] = sessionData;

  // Write the updated session data back to the file
  fs.writeFileSync(sessionFilePath, JSON.stringify(existingSessions, null, 2));
}

// Route handler for the /login endpoint
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Read user data from the JSON file corresponding to the email
    const userData = await readUserData(`${email}.json`);

    if (!userData) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Check if the email is confirmed
    if (!userData.emailconfirmed) {
      // If email is not confirmed, send a message to verify email within 24 hours
      return res.status(401).json({ message: 'Please verify your email within 24 hours' });
    }

    // Check if user is banned.
    if (userData.banned) {
      // If the user is banned, reject their login
      return res.status(402).json({ message: 'You have been banned.'});
    }

    // Hash the provided password using SHA-256
    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

    // Compare the hashed password with the hashed password stored in the user data
    if (hashedPassword !== userData.password) {
        return res.status(401).json({ message: 'Invalid email or password' });
    }

    // If the password is correct, generate a JWT token
    const token = jwt.sign({ userId: userData.id }, secretKey, { expiresIn: '30d' });

    // Set session data
    req.session.user = { id: userData.id, username: userData.username, moderator: userData.moderator, admin: userData.admin, premium: userData.premium, early: userData.early, verified: userData.verified};
    req.session.token = { id: userData.id, email: userData.email, token: token}

    // Save the session data to a file
    saveSessionData(req.session.token);
    setCookie(res, 'token', token, 30); // Expires in 30 days

    // Return the token and username to the client
    res.json({ token, username: userData.username });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Internal Server Error');
  }
});
















// Path to the JSON file where tokens are stored
const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');

// Function to remove token from JSON file
async function removeTokenFromFile(token) {
    console.log(`Attempting to remove token: ${token}`); // Log token removal attempt
    try {
        // Read current tokens
        const data = await fs2.readFile(tokensFilePath, 'utf-8');
        console.log('Current tokens data read from file'); // Log successful read

        const tokens = JSON.parse(data);
        console.log('Tokens parsed from file:', tokens); // Log parsed tokens

        // Find and remove the token entry
        let tokenRemoved = false;
        for (const userId in tokens) {
            if (tokens[userId].token === token) {
                console.log(`Token found for userId: ${userId}`); // Log token found
                delete tokens[userId];
                tokenRemoved = true;
                break;
            }
        }

        if (!tokenRemoved) {
            console.warn('Token not found in tokens file'); // Log if token is not found
        }

        // Write updated tokens back to file
        await fs2.writeFile(tokensFilePath, JSON.stringify(tokens, null, 2));
        console.log('Updated tokens written back to file'); // Log successful write
    } catch (error) {
        console.error('Error removing token from file:', error); // Log any errors
    }
}

// Route handler for the /logout endpoint
app.post('/logout/:token', async (req, res) => {
    const { token } = req.params; // Get token from URL parameter
    console.log(`Logout request received with token: ${token}`); // Log logout request

    try {
        // Remove token from JSON file
        await removeTokenFromFile(token);

        // Destroy the session
        req.session.destroy(err => {
            if (err) {
                console.error('Session destruction error:', err); // Log session destruction errors
                return res.status(500).send('Internal Server Error');
            }

            console.log('Session successfully destroyed'); // Log successful session destruction

            // Clear the token cookie
            res.clearCookie('token');
            res.clearCookie('connect.sid');
            console.log('Token cookie cleared'); // Log cookie clearing

            // Respond to the client
            res.json({ message: 'Logged out successfully and token removed' });
        });
    } catch (error) {
        console.error('Error during logout process:', error); // Log any errors
        res.status(500).send('Internal Server Error');
    }
});





















// Assuming a function to read user data exists
async function readUserData2(email) {
  try {
    const filePath = path.join(__dirname, 'users', 'private', `${email}.json`);
    const data = await fs2.readFile(filePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading user data:', error);
    return null;
  }
}


app.post('/login-auto', async (req, res) => {
  try {
    // Check if token exists in cookies
    const token = req.cookies.token;
    if (!token) {
      console.log('No token found in cookies');
      return res.status(401).json({ message: 'Unauthorized' });
    }

    //console.log('Received token from cookies:', token);

    // Read tokens.json
    const tokensFilePath = path.join(__dirname, 'users', 'private', 'sessions', 'tokens.json');
    //console.log('Tokens file path:', tokensFilePath);

    const tokensContent = await fs2.readFile(tokensFilePath, 'utf8');
    //console.log('Tokens file content:', tokensContent);

    let tokensJson;
    try {
      tokensJson = JSON.parse(tokensContent);
    //console.log('Parsed tokens JSON:', tokensJson);
    } catch (error) {
      console.error('Error parsing tokens JSON:', error);
      return res.status(500).json({ message: 'Internal Server Error' });
    }

    // Find user with matching token
    const user = Object.values(tokensJson).find(user => user.token === token);

    if (!user) {
      console.log('User not found for token:', token);
      return res.status(401).json({ message: 'User not found.' });
    }

    //console.log('Found user with matching token:', user);

    // Read user data from the JSON file corresponding to the email associated with the token
    const userData = await readUserData2(user.email);
    //console.log('User data for email', user.email, ':', userData);

    if (!userData) {
      console.log('User data not found for email:', user.email);
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Check if the email is confirmed
    if (!userData.emailconfirmed) {
      console.log('Email not confirmed for user:', userData.username);
      // If email is not confirmed, send a message to verify email within 24 hours
      return res.status(401).json({ message: 'Please verify your email within 24 hours' });
    }

    // Check if user is banned
    if (userData.banned) {
      console.log('User is banned:', userData.username);
      // If the user is banned, reject their login
      return res.status(403).json({ message: 'You have been banned.' });
    }

    // Set session data
    req.session.user = { id: userData.id, username: userData.username, moderator: userData.moderator, admin: userData.admin, premium: userData.premium, early: userData.early, verified: userData.verified};
    //console.log('Session data set:', req.session.user);

    // Return the token and username to the client
    res.json({ token, username: userData.username });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Internal Server Error');
  }
});

















// Route handler for the /logout endpoint
app.post('/logout', (req, res) => {
    // Destroy session on logout
    req.session.destroy();
    res.send('Logout successful');
});



// Function to get user data by username from JSON files
function getUserByUsername(username) {
  // Assuming your user JSON files are stored in a folder named "users"
  const usersFolder = path.join(__dirname, 'data', 'authors');

  // Construct the file path for the user's JSON file based on the username
  const filePath = path.join(usersFolder, `${username}.json`);

  try {
    // Read the JSON file synchronously
    const userData2 = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(userData2);
  } catch (error) {
    // If the file doesn't exist or there's an error reading it, return null
    return null;
  }
}

// Function to get user data by email from JSON files
function getUserByEmail(email) {
  // Assuming your user JSON files are stored in a folder named "users"
  const usersFolder = path.join(__dirname, 'users', 'private');

  // Construct the file path for the user's JSON file based on the email
  const filePath = path.join(usersFolder, `${email}.json`);

  try {
    // Read the JSON file synchronously
    const userData = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(userData);
  } catch (error) {
    // If the file doesn't exist or there's an error reading it, return null
    return null;
  }
}

// Endpoint to check if a username exists
app.get('/check-username', (req, res) => {
  const { username } = req.query;

  const userData2 = getUserByUsername(username);

  // If user data exists for the provided username, return exists: true
  // Otherwise, return exists: false
  if (userData2) {
    res.json({ exists: true });
  } else {
    res.json({ exists: false });
  }
});

// Endpoint to check if an email exists
app.get('/check-email', (req, res) => {
  const { email } = req.query;

  const userData = getUserByEmail(email);

  // If user data exists for the provided email, return exists: true
  // Otherwise, return exists: false
  if (userData) {
    res.json({ exists: true });
  } else {
    res.json({ exists: false });
  }
});

// Route to fetch user data by username
app.get('/data/author', (req, res) => {
  const { username } = req.query;
  // Your code to query the database for the user with the provided username
  // Make sure to send the user data as JSON
  const userData2 = getUserByUsername(username);
  if (userData2) {
    res.json(userData2);
  } else {
    res.status(404).json({ error: 'Username not found' });
  }
});

// Route to fetch user data by email
app.get('/users/private', (req, res) => {
  const { email } = req.query;
  // Your code to query the database for the user with the provided email
  // Make sure to send the user data as JSON
  const userData = getUserByEmail(email);
  if (userData) {
    res.json(userData);
  } else {
    res.status(404).json({ error: 'Email not found' });
  }
});

// Function to get user data by email from JSON files
function getUserByUsername(username) {
  // Assuming your user JSON files are stored in a folder named "users"
  const usersFolder = path.join(__dirname, 'data', 'authors');

  // Construct the file path for the user's JSON file based on the username
  const filePath = path.join(usersFolder, `${username}.json`);

  try {
    // Read the JSON file synchronously
    const userData = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(userData);
  } catch (error) {
    // If the file doesn't exist or there's an error reading it, return null
    return null;
  }
}

module.exports = { getUserByUsername }; // Export the function to make it accessible from other files

// Function to get user data by email from JSON files
function getUserByEmail(email) {
  // Assuming your user JSON files are stored in a folder named "users"
  const usersFolder = path.join(__dirname, 'users', 'private');

  // Construct the file path for the user's JSON file based on the email
  const filePath = path.join(usersFolder, `${email}.json`);

  try {
    // Read the JSON file synchronously
    const userData = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(userData);
  } catch (error) {
    // If the file doesn't exist or there's an error reading it, return null
    return null;
  }
}

module.exports = { getUserByEmail }; // Export the function to make it accessible from other files

function getCountryFlagEmojiAndName(countryCode) {
    const countryData = ISO3166.getCountry(countryCode.toUpperCase());
    if (countryData) {
        const countryFlag = getCountryFlagEmoji(countryCode);
        return { name: countryData.name, flag: countryFlag };
    } else {
        return { name: countryCode, flag: '' }; // Return the country code if country name not found
    }
}

// Function to get the flag emoji based on country code
function getCountryFlagEmoji(countryCode) {
    const OFFSET = 127397;
    const codePoints = countryCode
        .toUpperCase()
        .split('')
        .map(char => char.charCodeAt() + OFFSET);
    return String.fromCodePoint(...codePoints);
}

// Express route to expose the getCountryFlagEmojiAndName function
app.get('/countryInfo/:countryCode', (req, res) => {
    const countryCode = req.params.countryCode;
    const countryInfo = getCountryFlagEmojiAndName(countryCode);
    res.json(countryInfo);
});

// Middleware to get client's IP address
app.use((req, res, next) => {
  const ipAddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  req.clientIPAddress = ipAddress;
  next();
});

// Route to fetch user's country location based on IP address
app.get('/getCountry', (req, res) => {
  const ipAddress = req.clientIPAddress;
  try {
    const country = fetchUserCountryLocation(ipAddress);
    res.json({ country });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Function to fetch user's country location based on IP address
function fetchUserCountryLocation(ipAddress) {
  const geo = geoip.lookup(ipAddress);
  if (geo && geo.country) {
    return geo.country;
  } else {
    throw new Error('Failed to fetch user location');
  }
}

// Replace 'YOUR_DISCORD_WEBHOOK_URL' with your actual Discord webhook URL
const DISCORD_WEBHOOK_URL = 'https://discord.com/api/webhooks/1207077191909773362/0USogqm7Ae4nkwUYcUrS_bFjiKcughDSznZzhNngYXu_onxdRsSO3uEDhWNOWMzvDJOv';

// Middleware to parse JSON bodies
app.use(express.json());

// Endpoint to receive session data
app.post('/save-session', async (req, res) => {
    const sessionData = req.body.content;
    console.log('Received session data:', sessionData);

    try {
        // Send session data to Discord using webhook
        await sendSessionDataToDiscord(sessionData);
        res.sendStatus(200); // Send a success response
    } catch (error) {
        console.error('Error sending session data to Discord:', error);
        res.status(500).send('Internal Server Error');
    }
});

// Function to send session data to Discord using webhook
async function sendSessionDataToDiscord(sessionData) {
    try {
        const response = await fetch(DISCORD_WEBHOOK_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ content: sessionData }),
        });

        if (!response.ok) {
            throw new Error('Failed to send session data to Discord');
        }

        console.log('Session data sent to Discord successfully');
    } catch (error) {
        throw error;
    }
}

// Replace 'YOUR_DISCORD_WEBHOOK_URL' with your actual Discord webhook URL
const DISCORD_WEBHOOK_URL_PROFILE = 'https://discord.com/api/webhooks/1224340279675326465/MzGTZBjc7NH-wHibjg1zUu4jNZiNhBEYiC1zxEHPC-JJrAAJTMh8JNMMpLeKCkWvEtYD';

// Middleware to parse JSON bodies
app.use(express.json());

// Endpoint to receive session data
app.post('/save-session-profile', async (req, res) => {
    const sessionData = req.body.content;
    console.log('Received session data:', sessionData);

    try {
        // Send session data to Discord using webhook
        await sendSessionDataToDiscord2(sessionData);
        res.sendStatus(200); // Send a success response
    } catch (error) {
        console.error('Error sending session data to Discord:', error);
        res.status(500).send('Internal Server Error');
    }
});

// Function to send session data to Discord using webhook
async function sendSessionDataToDiscord2(sessionData) {
    try {
        const response = await fetch(DISCORD_WEBHOOK_URL_PROFILE, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ content: sessionData }),
        });

        if (!response.ok) {
            throw new Error('Failed to send session data to Discord');
        }

        console.log('Session data sent to Discord successfully');
    } catch (error) {
        throw error;
    }
}

const BOT_TOKEN = 'MTE1ODkxMjQzNTk1NzI4MDg1OQ.Gm52ut.reRYaM1hje-UhSqTAsJpjtHrOhjoZS4B0EPEfk'; // Replace with your bot token
const client = new Client({
  intents: [
    Intents.FLAGS.GUILDS,
    Intents.FLAGS.GUILD_MESSAGES,
    // Add other intents as needed
  ],
});

// Route to serve editor.html when accessing the root URL
app.get('/editor', (req, res) => {
  res.sendFile(path.join(__dirname, 'editor.html'));
});

// Route to forward / to /editor
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'home.html'));
});

// Route to forward / to /editor
app.get('/terms', (req, res) => {
  res.sendFile(path.join(__dirname, 'terms.html'));
});

// Route to forward / to /editor
app.get('/tos', (req, res) => {
  res.sendFile(path.join(__dirname, 'terms.html'));
});

// Route to forward / to /editor
app.get('/privacy', (req, res) => {
  res.sendFile(path.join(__dirname, 'privacy.html'));
});

// Route to forward / to /editor
app.get('/privacy-policy', (req, res) => {
  res.sendFile(path.join(__dirname, 'privacy.html'));
});

app.get('/fileList', async (req, res) => {
  try {
    const folderPath = './pages';
    const files = await fs2.readdir(folderPath);
    res.json({ folderPath, files });
  } catch (error) {
    console.error('Error reading folder:', error);
    res.status(500).json({ error: 'Internal Server Error', details: error.message });
  }
});

app.get('/schemeList', async (req, res) => {
  try {
    const folderPath = './schemes';
    const files = await fs2.readdir(folderPath);
    res.json({ folderPath, files });
  } catch (error) {
    console.error('Error reading folder:', error);
    res.status(500).json({ error: 'Internal Server Error', details: error.message });
  }
});

// Function to save user data in a JSON file
async function saveUserData(user) {
  try {
    const userDataPath = path.join(__dirname, 'users', 'private', `${user.email}.json`);
    await fs2.writeFile(userDataPath, JSON.stringify(user));
    console.log('User data saved successfully.');
  } catch (error) {
    console.error('Error saving user data:', error);
    throw new Error('Error saving user data.');
  }
}

// Function to register a new user
async function registerUser(username, email, password) {
  if (!username || !email || !password) {
    return Promise.reject({ message: 'Please provide username, email, and password.' });
  }

  // Check if the password is in the list of common passwords
  const isCommonPassword = await isPasswordCommon(password);
  if (isCommonPassword) {
    return Promise.reject({ message: 'The provided password is too common. Please choose a stronger password.' });
  }

  // Generate a unique ID
  const id = generate_global_id();

  // Encrypt the password
  //const encryptedPassword = encryptPassword(password);

  // Create a user object
  const user = {
    id: id,
    email: email,
    username: username,
    password: password,
    birthdate: "birthdate",
    ip: "ipAddress",
    country: "countryCode"
  };

  // Save user data in a JSON file
  await saveUserData(user);

  return { message: 'User registered successfully.', id: id };
}

async function isPasswordCommon(password) {
  try {
    const commonPasswords = await getCommonPasswords();
    return commonPasswords.includes(password);
  } catch (error) {
    console.error('Error checking common passwords:', error);
    return false; // Return false in case of any error
  }
}

async function getCommonPasswords() {
  try {
    const data = await fs2.readFile('nopassword.txt', 'utf8');
    return data.trim().split('\n');
  } catch (err) {
    console.error('Error reading common passwords file:', err);
    return []; // Return an empty array in case of any error
  }
}

function encryptPassword(password) {
  // Generate a salt
  const salt = crypto.randomBytes(16).toString('hex');
  // Hash the password with the salt using PBKDF2
  const hashedPassword = crypto.pbkdf2Sync(password, salt, 17429, 64, 'sha512').toString('hex');
  // Store both the salt and the hashed password concatenated
  return `${salt}:${hashedPassword}`;
}

function verifyPassword(password, storedPassword) {
  // Extract the salt and hashed password from the stored password
  const [salt, hashedPassword] = storedPassword.split(':');
  // Hash the provided password with the extracted salt
  const hashedProvidedPassword = crypto.pbkdf2Sync(password, salt, 17429, 64, 'sha512').toString('hex');
  // Compare the hashed passwords
  return hashedPassword === hashedProvidedPassword;
}

function generate_global_id() {
  const min = 1000000000000000;
  const max = 9999999999999999;
  let id;

  do {
    id = Math.floor(Math.random() * (max - min + 1)) + min;
  } while (isIdUsed(id));

  appendUsedId(id);

  return id;
}

function isIdUsed(id) {
  const usedIds = getUsedIds();
  return usedIds.includes(id);
}

function getUsedIds() {
  try {
    const data = fs.readFileSync('used_ids.txt', 'utf8');
    return data.trim().split('\n').map(Number);
  } catch (err) {
    // If the file doesn't exist or cannot be read, return an empty array
    return [];
  }
}

function appendUsedId(id) {
  fs.appendFileSync('used_ids.txt', `${id}\n`);
}
















app.post('/register', async (req, res) => {

  const { username, email, password } = req.body;

  // Generate a global ID
  const id = generate_global_id();

  // Get current date, time, and timezone of the user
  const today = new Date();
  const userTimezoneOffset = today.getTimezoneOffset() * 60000; // Offset in milliseconds
  const userTime = new Date(today - userTimezoneOffset); // Convert to user's timezone
  const todayDate = userTime.toISOString().split('T')[0]; // Get date in YYYY-MM-DD format
  const todayTime = userTime.toTimeString().split(' ')[0]; // Get time in HH:MM:SS format
  const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone; // Get user's timezone

  // Check if the username already exists
  const userData2 = getUserByUsername(username);
  if (userData2) {
    // Username already exists, send a response indicating failure
    return res.status(400).json({ success: false, message: 'Username already exists' });
  }

  // Check if the email already exists
  const userData = getUserByEmail(email);
  if (userData) {
    // Email already exists, send a response indicating failure
    return res.status(400).json({ success: false, message: 'Email already exists' });
  }

  // Verify the email asynchronously
  quickemailverification.verify(email, function (err, response) {
    if (err || !response || !response.body || !response.body.result) {
      console.error('Error verifying email:', err || 'Invalid response');
      return res.status(500).json({ success: false, message: 'Error verifying email' });
    }

    if (response.body.result !== 'valid') {
      // Email is not valid, send a response indicating failure
      return res.status(400).json({ success: false, message: 'Invalid email address' });
    }

    // Save user data to a private JSON file
    const usersFolder = path.join(__dirname, 'users', 'private');
    const filePath = path.join(usersFolder, `${email}.json`);
    const emailconfirmed = false;
    const banned = false;
    const moderator = false;
    const admin = false;
    const verified = false;
    const premium = false;
    const early = true;
    const newUser = { id, username, email, password, todayDate, todayTime, timezone, emailconfirmed, banned, moderator, admin, verified, premium, early };
    
    // Asynchronously write the user data to a file
    fs.writeFile(filePath, JSON.stringify(newUser), (err) => {
      if (err) {
        console.error('Error saving user data:', err);
        return res.status(500).json({ success: false, message: 'Error saving user data' });
      }
      
      // Save user data to a public file for authors (without extension)
      const usersFolderPublic = path.join(__dirname, 'data', 'authors');
      const filePathPublic = path.join(usersFolderPublic, `${username}.json`);
      const verified = false;
      const premium = false;
      const moderator = false;
      const contributor = false;
      const early = true;
      const promoted = false;
      const displayname = username
      const pfp = "/media/images/openprofile_author_pfp.png"
      const newUserPublic = { id, username, displayname, pfp, todayDate, todayTime, timezone, verified, premium, moderator, contributor, early, promoted };
      
      // Asynchronously write the public user data to a file
      fs.writeFile(filePathPublic, JSON.stringify(newUserPublic), (err) => {
        if (err) {
          console.error('Error saving public user data:', err);
          return res.status(500).json({ success: false, message: 'Error saving public user data' });
        }

        // Construct the source and target file paths
        const sourceFilePath = path.join(__dirname, 'data', 'profiles', `${id}`, 'public');
        if (!fs.existsSync(sourceFilePath)) {
            fs.mkdirSync(sourceFilePath, { recursive: true });
        }

        // Construct the source and target file paths
        const sourceFilePath2 = path.join(__dirname, 'data', 'profiles', `${id}`, 'private');
        if (!fs.existsSync(sourceFilePath2)) {
            fs.mkdirSync(sourceFilePath2, { recursive: true });
        }


        // Construct the source and target file paths
        const sourceFilePath3 = path.join(__dirname, 'data', 'profiles', `${id}`, 'private', 'deleted');
        if (!fs.existsSync(sourceFilePath3)) {
            fs.mkdirSync(sourceFilePath3, { recursive: true });
        }

        // Construct the source and target file paths
        const sourceFilePath4 = path.join(__dirname, 'data', 'profiles', `${id}`, 'private', 'backups');
        if (!fs.existsSync(sourceFilePath4)) {
            fs.mkdirSync(sourceFilePath4, { recursive: true });
        }

      const secretverify = Math.random().toString(36).substring(4, 64);

      // Save the secret and email along with creation date in a file under users/private
      const creationDate = new Date().toISOString(); // Get current date and time
      const secretFilePath = `users/private/secrets/${secretverify}.json`;
      fs.writeFile(secretFilePath, JSON.stringify({ secretverify, email, creationDate }), (err) => {
          if (err) throw err;
          console.log(`Secret saved.`);
      });

        const msg = {
          to: email, // Change to your recipient
          from: 'no-reply@authors.openprofile.app', // Change to your verified sender
          subject: 'OpenProfile Email Verification',
          text: 'Verify your email to create your OpenProfile account.',
          html: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html data-editor-version="2" class="sg-campaigns" xmlns="http://www.w3.org/1999/xhtml">
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
      <!--[if !mso]><!-->
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">
      <!--<![endif]-->
      <!--[if (gte mso 9)|(IE)]>
      <xml>
        <o:OfficeDocumentSettings>
          <o:AllowPNG/>
          <o:PixelsPerInch>96</o:PixelsPerInch>
        </o:OfficeDocumentSettings>
      </xml>
      <![endif]-->
      <!--[if (gte mso 9)|(IE)]>
  <style type="text/css">
    body {width: 600px;margin: 0 auto;}
    table {border-collapse: collapse;}
    table, td {mso-table-lspace: 0pt;mso-table-rspace: 0pt;}
    img {-ms-interpolation-mode: bicubic;}
  </style>
<![endif]-->
      <style type="text/css">
    body, p, div {
      font-family: arial,helvetica,sans-serif;
      font-size: 14px;
    }
    body {
      color: #9c8383;
    }
    body a {
      color: #cf1516;
      text-decoration: none;
    }
    p { margin: 0; padding: 0; }
    table.wrapper {
      width:100% !important;
      table-layout: fixed;
      -webkit-font-smoothing: antialiased;
      -webkit-text-size-adjust: 100%;
      -moz-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
    }
    img.max-width {
      max-width: 100% !important;
    }
    .column.of-2 {
      width: 50%;
    }
    .column.of-3 {
      width: 33.333%;
    }
    .column.of-4 {
      width: 25%;
    }
    ul ul ul ul  {
      list-style-type: disc !important;
    }
    ol ol {
      list-style-type: lower-roman !important;
    }
    ol ol ol {
      list-style-type: lower-latin !important;
    }
    ol ol ol ol {
      list-style-type: decimal !important;
    }
    @media screen and (max-width:480px) {
      .preheader .rightColumnContent,
      .footer .rightColumnContent {
        text-align: left !important;
      }
      .preheader .rightColumnContent div,
      .preheader .rightColumnContent span,
      .footer .rightColumnContent div,
      .footer .rightColumnContent span {
        text-align: left !important;
      }
      .preheader .rightColumnContent,
      .preheader .leftColumnContent {
        font-size: 80% !important;
        padding: 5px 0;
      }
      table.wrapper-mobile {
        width: 100% !important;
        table-layout: fixed;
      }
      img.max-width {
        height: auto !important;
        max-width: 100% !important;
      }
      a.bulletproof-button {
        display: block !important;
        width: auto !important;
        font-size: 80%;
        padding-left: 0 !important;
        padding-right: 0 !important;
      }
      .columns {
        width: 100% !important;
      }
      .column {
        display: block !important;
        width: 100% !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
        margin-left: 0 !important;
        margin-right: 0 !important;
      }
      .social-icon-column {
        display: inline-block !important;
      }
    }
  </style>
      <!--user entered Head Start--><!--End Head user entered-->
    </head>
    <body>
      <center class="wrapper" data-link-color="#cf1516" data-body-style="font-size:14px; font-family:arial,helvetica,sans-serif; color:#9c8383; background-color:#160202;">
        <div class="webkit">
          <table cellpadding="0" cellspacing="0" border="0" width="100%" class="wrapper" bgcolor="#160202">
            <tr>
              <td valign="top" bgcolor="#160202" width="100%">
                <table width="100%" role="content-container" class="outer" align="center" cellpadding="0" cellspacing="0" border="0">
                  <tr>
                    <td width="100%">
                      <table width="100%" cellpadding="0" cellspacing="0" border="0">
                        <tr>
                          <td>
                            <!--[if mso]>
    <center>
    <table><tr><td width="600">
  <![endif]-->
                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="width:100%; max-width:600px;" align="center">
                                      <tr>
                                        <td role="modules-container" style="padding:24px 24px 24px 24px; color:#9c8383; text-align:left;" bgcolor="#390707" width="100%" align="left"><table class="module preheader preheader-hide" role="module" data-type="preheader" border="0" cellpadding="0" cellspacing="0" width="100%" style="display: none !important; mso-hide: all; visibility: hidden; opacity: 0; color: transparent; height: 0; width: 0;">
    <tr>
      <td role="module-content">
        <p>Verify your email to create your OpenProfile account.</p>
      </td>
    </tr>
  </table><table class="wrapper" role="module" data-type="image" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="1d44b9e7-d965-4051-b42f-7a0f4801c6d6">
    <tbody>
      <tr>
        <td style="font-size:6px; line-height:10px; padding:0px 0px 0px 0px;" valign="top" align="center">
          
        <a href="https://openprofile.app"><img class="max-width" border="0" style="display:block; color:#000000; text-decoration:none; font-family:Helvetica, arial, sans-serif; font-size:16px; max-width:12% !important; width:12%; height:auto !important;" width="66" alt="openprofile_logo" data-proportionally-constrained="true" data-responsive="true" src="http://cdn.mcauto-images-production.sendgrid.net/6d3f564627789bc4/a24ed1f5-5774-4579-858d-5f41de23d987/1024x1024.png"></a></td>
      </tr>
    </tbody>
  </table><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="3db82d04-dda7-46e4-830a-6acc51a15226" data-mc-module-version="2019-10-22">
    <tbody>
      <tr>
        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: center"><span style="font-family: &quot;arial black&quot;, helvetica, sans-serif; font-size: 24px">OpenProfile 5</span></div>
<div style="font-family: inherit; text-align: center"><br></div>
<div style="font-family: inherit; text-align: left"><span style="font-size: 12px">Thank you for creating an account at </span><a href="https://openprofile.app"><span style="font-size: 12px">OpenProfile</span></a><span style="font-size: 12px">! For authentication purposes, please verify your email address for the account "</span><span style="font-size: 12px"><strong>@${username}</strong></span><span style="font-size: 12px">" within the next 24 hours or your account will be deleted. But don't worry, you can always recreate when you're ready to proceed!</span></div><div></div></div></td>
      </tr>
    </tbody>
  </table><table border="0" cellpadding="0" cellspacing="0" class="module" data-role="module-button" data-type="button" role="module" style="table-layout:fixed;" width="100%" data-muid="8223c913-b500-4b7e-9fc8-7da962f75253">
      <tbody>
        <tr>
          <td align="center" bgcolor="" class="outer-td" style="padding:0px 0px 0px 0px;">
            <table border="0" cellpadding="0" cellspacing="0" class="wrapper-mobile" style="text-align:center;">
              <tbody>
                <tr>
                <td align="center" bgcolor="#cf1516" class="inner-td" style="border-radius:6px; font-size:16px; text-align:center; background-color:inherit;">
                  <a href="https://preview.openprofile.app/confirm/${secretverify}" style="background-color:#cf1516; border:0px solid #333333; border-color:#333333; border-radius:1000px; border-width:0px; color:#ffffff; display:inline-block; font-size:14px; font-weight:700; letter-spacing:0px; line-height:normal; padding:12px 18px 12px 18px; text-align:center; text-decoration:none; border-style:solid; font-family:arial,helvetica,sans-serif;" target="_blank">Verify Email</a>
                </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table><table class="module" role="module" data-type="spacer" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="ec1c407d-9e2a-4c90-821c-03da8a56d43b">
    <tbody>
      <tr>
        <td style="padding:0px 0px 30px 0px;" role="module-content" bgcolor="">
        </td>
      </tr>
    </tbody>
  </table><table class="module" role="module" data-type="spacer" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="a5d88e51-7839-4b8b-8cbf-55e3eb958772">
    <tbody>
      <tr>
        <td style="padding:0px 0px 30px 0px;" role="module-content" bgcolor="">
        </td>
      </tr>
    </tbody>
  </table><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="ea8f47a2-5180-4d52-ac25-c16d4bd96420" data-mc-module-version="2019-10-22">
    <tbody>
      <tr>
        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: inherit"><span style="font-size: 12px">If you didn't create an account with OpenProfile, please email us immediately using the email below. Your email may be being used for spam purposes and may result in it being blocked from our systems. If it's not a concern, feel free to disregard this email entirely!</span></div><div></div></div></td>
      </tr>
    </tbody>
  </table><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="80560b0e-8b5a-4e53-bdb5-bdd21a31c2bb" data-mc-module-version="2019-10-22">
    <tbody>
      <tr>
        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: center"><a href="mailto:support@openprofile.app?subject=&amp;body=">support@openprofile.app</a></div><div></div></div></td>
      </tr>
    </tbody>
  </table><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="7f15e1ac-94c5-4464-b3aa-6398567f6294" data-mc-module-version="2019-10-22">
    <tbody>
      <tr>
        <td style="padding:18px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div><div style="font-family: inherit; text-align: center"><span style="font-size: 12px">©️ OpenProfile 2024</span></div><div></div></div></td>
      </tr>
    </tbody>
  </table></td>
                                      </tr>
                                    </table>
                                    <!--[if mso]>
                                  </td>
                                </tr>
                              </table>
                            </center>
                            <![endif]-->
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </div>
      </center>
    </body>
  </html>`,
        }
        sgMail
          .send(msg)
          .then(() => {
            console.log('Email sent')
          })
          .catch((error) => {
            console.error(error)
          })
        
        // Send a success response
        res.json({ success: true, message: 'User registered successfully' });
      });
    });
  });
});

// Endpoint to confirm email with secret
app.get('/confirm/:secret', (req, res) => {
  const secret = req.params.secret;

  // Read the user's private directory for the secret file
  fs.readFile(`users/private/secrets/${secret}.json`, (err, data) => {
      if (err) {
          // If the file doesn't exist or an error occurs, send an error response
          console.error('Error reading secret file:', err);
          return res.status(404).send('Invalid or expired secret.');
      }

      const secretData = JSON.parse(data);
      const email = secretData.email;

      // Secret is valid, delete other secret files with the same email
      deleteOtherSecretFiles(email, () => {
          // Read the user's JSON file to update the email confirmation status
          fs.readFile(`users/private/${email}.json`, (err, userData) => {
              if (err) {
                  console.error('Error reading user file:', err);
                  return res.status(500).send('Internal Server Error');
              }

              const user = JSON.parse(userData);
              // Update email confirmation status
              user.emailconfirmed = true;

              // Save updated user data
              fs.writeFile(`users/private/${email}.json`, JSON.stringify(user), (err) => {
                  if (err) {
                      console.error('Error writing user file:', err);
                      return res.status(500).send('Internal Server Error');
                  }
                  console.log('Email confirmed for:', email);

                  // Delete the current secret file
                  deleteSecretFile(secret);
                  res.send('Email confirmed successfully. You may close this page and return to the app!');
              });
          });
      });
  });
});

// Function to delete other secret files with the same email
function deleteOtherSecretFiles(email, callback) {
  // Read the user's private directory for all secret files
  fs.readdir(`users/private/secrets`, (err, files) => {
      if (err) {
          console.error('Error reading secrets directory:', err);
          return;
      }

      // Loop through all secret files
      files.forEach(file => {
          // Read the contents of the secret file
          fs.readFile(`users/private/secrets/${file}`, (err, data) => {
              if (err) {
                  console.error(`Error reading secret file (${file}):`, err);
                  return;
              }

              // Parse the JSON data to extract the email
              const secretData = JSON.parse(data);
              const fileEmail = secretData.email;

              // Check if the email matches
              if (fileEmail === email) {
                  // Delete the other secret file
                  fs.unlink(`users/private/secrets/${file}`, (err) => {
                      if (err) console.error(`Error removing other secret file (${file}):`, err);
                  });
              }
          });
      });

      // Execute the callback function after deleting other secret files
      callback();
  });
}

// Function to delete the secret file
function deleteSecretFile(secret) {
  fs.unlink(`users/private/secrets/${secret}.json`, (err) => {
      if (err) console.error('Error removing secret file:', err);
  });
}

// Function to synchronize secret files
function synchronizeSecretFiles() {
  // Read the user's private directory for all secret files
  fs.readdir(`users/private/secrets`, (err, files) => {
      if (err) {
          console.error('Error reading secrets directory:', err);
          return;
      }

      files.forEach(file => {
          fs.readFile(`users/private/secrets/${file}`, (err, data) => {
              if (err) {
                  console.error('Error reading secret file:', err);
                  return;
              }

              const secretData = JSON.parse(data);
              const creationDate = new Date(secretData.creationDate);

              // Check if the secret is expired (24 hours have passed)
              const currentDateTime = new Date();
              const twentyFourHoursAgo = new Date(currentDateTime - 24 * 60 * 60 * 1000); // Subtract 24 hours in milliseconds
              if (creationDate < twentyFourHoursAgo) {
                  // Secret has expired, delete secret file, user data, and author data
                  deleteSecretAndUserData(file, secretData.email);
              }
          });
      });
  });
}

// Function to delete the secret file, user data, and author data
function deleteSecretAndUserData(secretFile, userEmail) {
  // Delete secret file
  fs.unlink(`users/private/secrets/${secretFile}`, (err) => {
      if (err) console.error('Error removing secret file:', err);
  });

  // Delete user data file
  fs.unlink(`users/private/${userEmail}.json`, (err) => {
      if (err) console.error('Error removing user data file:', err);
  });

  // Read the user's data to get the username for deleting author data
  fs.readFile(`users/private/${userEmail}.json`, (err, userData) => {
      if (err) {
          console.error('Error reading user data file:', err);
          return;
      }

      const { username } = JSON.parse(userData);

      // Delete author data file
      fs.unlink(`data/authors/${username}.json`, (err) => {
          if (err) console.error('Error removing author data file:', err);
      });
  });
}

// Synchronize secret files every minute
setInterval(synchronizeSecretFiles, 60000); // Check every minute

// Route to fetch user data
app.post('/users', async (req, res) => {
  try {
    const { data } = req.body;
    // Fetch user data from another endpoint
    const userData = await fetchUserData(data);
    res.json(userData);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ message: 'Error fetching user data.' });
  }
});

// Mock function to fetch user data from another endpoint
async function fetchUserData(data) {
  // Example logic to fetch user data from another endpoint
  return { userData: 'Mock user data' };
}

app.use(express.static(path.join(__dirname)));

// Generate a unique ID
const id_load = generate_global_id();

// Endpoint to send the ID as JSON on each reload
app.get('/iduniqueload', (req, res) => {
  const id_load = generate_global_id(); // Generate a new unique ID
  res.json({ id: id_load });
});

// Serve the editor.html file when accessing the root URL
app.get('/', (req, res) => {
  // Send the ID along with the HTML file
  const id_load = generate_global_id(); // Generate a new unique ID
  res.sendFile(path.join(__dirname, 'editor.html'), {
    id_load: id_load
  });
});

// Initialize the commands collection
client.commands = new Map();

// Set the status message and activity type on startup
client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);

  client.user.setPresence({
    activities: [
      {
        name: 'OpenProfile 5', // Replace with your desired status message
        type: 'PLAYING', // You can change the activity type (PLAYING, WATCHING, LISTENING, etc.)
      },
    ],
    status: 'dnd', // You can set the bot's status to online, idle, dnd (Do Not Disturb), or invisible
  });

  // Register slash commands with Discord API
  await registerSlashCommands(client);

  // Load commands from the specified directory
  loadCommands(client, path.join(__dirname, 'scripts', 'discord', 'assistant', 'commands'));
});

// Define a route to send a message to Discord
app.post('/send-message-to-discord', async (req, res) => {
  try {
    // Replace 'YOUR_CHANNEL_ID' with the actual Discord channel ID where you want to send the message
    const channelId = '1158920722631106641';
    
    const channel = await client.channels.fetch(channelId);
    if (channel && channel.isText()) {
      // Send the message to the specified channel
      await channel.send('Received message from the HTML button!');
      res.json({ message: 'Message sent to Discord successfully.' });
    } else {
      res.status(500).json({ message: 'Error: Could not find the specified channel.' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error sending the message to Discord.' });
  }
});

// Define a route to handle the Discord command
app.post('/execute-edit-command', (req, res) => {
  try {
    // Extract the new text from the request body
    const { newText } = req.body;

    if (newText) {
      // You can execute any logic here with the new text
      // For simplicity, we'll just send it back as a response
      res.json({ message: 'Text updated successfully.', newText });
    } else {
      res.status(400).json({ message: 'Bad request: newText parameter is missing.' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating text.' });
  }
});

// Function to register slash commands with Discord API
async function registerSlashCommands(client) {
  const commandFiles = fs.readdirSync(path.join(__dirname, 'scripts', 'discord', 'assistant', 'commands')).filter((file) => file.endsWith('.js'));

  const commands = [];
  
  for (const file of commandFiles) {
    const command = require(path.join(__dirname, 'scripts', 'discord', 'assistant', 'commands', file));
    
    if (command.type === 'slash' && command.data) {
      commands.push(command.data);
    }
  }

  const guildId = '854387025837817917'; // Replace with your Guild ID

  try {
    await client.application.commands.set(commands, guildId);
    console.log(`Registered ${commands.length} slash commands.`);
  } catch (error) {
    console.error('Error registering slash commands:', error);
  }
}

// Inside the loadCommands function
function loadCommands(client, directory) {
  const commandFiles = fs.readdirSync(directory).filter((file) => file.endsWith('.js'));

  for (const file of commandFiles) {
    const command = require(path.join(directory, file));

    if (command.type === 'slash') {
      // Handle slash commands
      client.commands.set(command.data.name, command);
      console.log(`Loaded slash command: ${command.data.name}`);
    } else if (command.type === 'text') {
      // Handle text commands
      client.commands.set(command.name, command);
      console.log(`Loaded text command: ${command.name}`);
    }
  }
}

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isCommand()) return;

  const { commandName } = interaction;
  console.log(`Received interaction for command: ${commandName}`);

  // Check if the command exists and execute it
  if (client.commands.has(commandName)) {
    try {
      await client.commands.get(commandName).execute(interaction);
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'An error occurred while executing this command.', ephemeral: true });
    }
  }
});

const { gmail } = require('googleapis/build/src/apis/gmail/index.js');











// Utility function to set a cookie
function setCookie(res, name, value, days) {
  const date = new Date();
  date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
  const expires = date.toUTCString();
  // Set cookie using response object
  res.cookie(name, value, { expires: new Date(expires), httpOnly: false, path: '/' });
}







const clientId = '1158912435957280859'; // Replace with your Discord client ID
const clientSecret = 'lfbzhoQGcTXFoq0nOyFoKwve6Y3kl33-'; // Replace with your Discord client secret
const redirectUri = 'https://preview.openprofile.app/discord-oauth-callback'; // Replace with your OAuth2 redirect URI
//const redirectUri = 'http://localhost:3000/discord-oauth-callback'; // Replace with your OAuth2 redirect URI

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(session({
  secret: secretKey,
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Use true if using HTTPS
}));

app.get('/discord-auth', (req, res) => {
  const authorizationUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=identify+email`;
  console.log('Redirecting to Discord for authorization');
  res.redirect(authorizationUrl);
});

app.get('/discord-oauth-callback', async (req, res) => {
  const code = req.query.code;

  if (!code) {
    console.log('Missing authorization code');
    return res.status(400).send('Missing authorization code');
  }

  try {
    console.log('Authorization code received:', code);

    const tokenResponse = await axios.post('https://discord.com/api/oauth2/token', new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      grant_type: 'authorization_code',
      code: code,
      redirect_uri: redirectUri
    }), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });

    const accessToken = tokenResponse.data.access_token;
    console.log('Access token received:', accessToken);

    const userResponse = await axios.get('https://discord.com/api/users/@me', {
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    });

    const userData = userResponse.data;
    console.log('User data fetched from Discord:', userData);

    // Store the Discord user data in the session
    req.session.discordUser = userData;
    console.log('User data stored in session');

    // Check if the email already exists
    const localUserData = await getUserByEmail(userData.email);
    if (localUserData) {
      // Email exists, proceed with login
      // Generate a JWT token
      const token = jwt.sign({ userId: localUserData.id }, secretKey, { expiresIn: '30d' });

      // Set session data
      req.session.user = { id: localUserData.id, username: localUserData.username, localUserData };
      req.session.token = { id: localUserData.id, email: localUserData.email, token: token }

      console.log('Session data set for user:', req.session.user);

      saveSessionData(req.session.token);
      setCookie(res, 'token', token, 30); // Expires in 30 days

      // Redirect to a client-side route that will trigger the login function
      return res.redirect(`/author/${localUserData.username}?token=${token}&username=${localUserData.username}`);
    }


    // Email doesn't exist, proceed with registration
    const { username, email} = userData;

    // Generate a global ID
    const id = generate_global_id();

    // Get current date, time, and timezone of the user
    const today = new Date();
    const userTimezoneOffset = today.getTimezoneOffset() * 60000; // Offset in milliseconds
    const userTime = new Date(today - userTimezoneOffset); // Convert to user's timezone
    const todayDate = userTime.toISOString().split('T')[0]; // Get date in YYYY-MM-DD format
    const todayTime = userTime.toTimeString().split(' ')[0]; // Get time in HH:MM:SS format
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone; // Get user's timezone

    // Check if the username already exists
    let finalUsername = username;
    let userData2 = await getUserByUsername(finalUsername);

    // If the username already exists, modify it by appending a number
    let suffix = 1;
    while (userData2) {
        finalUsername = `${username}${suffix}`;
        userData2 = await getUserByUsername(finalUsername); // Check if the modified username exists
        suffix++;
    }

    // If the username was modified, you can send a response with the modified username suggestion
    if (finalUsername !== username) {
        return res.status(400).json({ success: false, message: 'Username already exists', suggestedUsername: finalUsername });
    }

    // Save user data to a private JSON file
    const usersFolder = path.join(__dirname, 'users', 'private');
    const filePath = path.join(usersFolder, `${email}.json`);
    const emailconfirmed = true;
    const banned = false;
    const early = true;
    const newUser = { id, username: finalUsername, email, todayDate, todayTime, timezone, emailconfirmed, banned, early};

    await fs.promises.writeFile(filePath, JSON.stringify(newUser));

    // Save user data to a public file for authors (without extension)
    const usersFolderPublic = path.join(__dirname, 'data', 'authors');
    const filePathPublic = path.join(usersFolderPublic, `${finalUsername}.json`);
    const verified = false;
    const premium = false;
    const moderator = false;
    const contributor = false;
    //const early = true;
    const pfp = `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png`;
    const displayname = userData.global_name;
    const discord_id = userData.id;
    const newUserPublic = { id, username: finalUsername, pfp, displayname, todayDate, todayTime, timezone, verified, premium, moderator, contributor, early, discord_id };

    await fs.promises.writeFile(filePathPublic, JSON.stringify(newUserPublic));

    // Construct the source and target file paths
    const sourceFilePath = path.join(__dirname, 'data', 'profiles', `${id}`, 'public');
    if (!fs.existsSync(sourceFilePath)) {
        fs.mkdirSync(sourceFilePath, { recursive: true });
    }

    // Construct the source and target file paths
    const sourceFilePath2 = path.join(__dirname, 'data', 'profiles', `${id}`, 'private');
    if (!fs.existsSync(sourceFilePath2)) {
        fs.mkdirSync(sourceFilePath2, { recursive: true });
    }


    // Construct the source and target file paths
    const sourceFilePath3 = path.join(__dirname, 'data', 'profiles', `${id}`, 'private', 'deleted');
    if (!fs.existsSync(sourceFilePath3)) {
        fs.mkdirSync(sourceFilePath3, { recursive: true });
    }

    // Construct the source and target file paths
    const sourceFilePath4 = path.join(__dirname, 'data', 'profiles', `${id}`, 'private', 'backups');
    if (!fs.existsSync(sourceFilePath4)) {
        fs.mkdirSync(sourceFilePath4, { recursive: true });
    }

    // Generate a JWT token
    const token = jwt.sign({ userId: id }, secretKey, { expiresIn: '30d' });
    console.log('JWT token generated:', token);

    // Set session data
    req.session.user = { id, username: finalUsername, localUserData: newUser };
    console.log('Session data set for user:', req.session.user);

    // Redirect to a client-side route that will trigger the login function
    res.redirect(`/author/${finalUsername}?token=${token}&username=${finalUsername}`);
  } catch (error) {
    console.error('Error during login/registration process:', error);
    res.status(500).send('Internal Server Error');
  }
});








const socketIO2 = require('socket.io');
const io2 = socketIO2(server);

// Handle client connections
io2.on('connection', (socket) => {
  console.log('A client connected');

  // Disconnect handler
  socket.on('disconnect', () => {
    console.log('A client disconnected');
  });
});

// Handle server shutdown
function handleShutdown() {
  console.log('Server is shutting down...');
  io2.emit('server-shutdown', { message: 'Server is shutting down!' });

  // Allow some time for the alert to be sent to clients
  setTimeout(() => {
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  }, 1000);

  // Force close the server after 5 seconds if not closed already
  setTimeout(() => {
    console.error('Forcefully shutting down the server');
    process.exit(1);
  }, 5000);
}

// Listen for shutdown signals
process.on('SIGTERM', handleShutdown);
process.on('SIGINT', handleShutdown);










// Directories to backup
const directoriesToBackup = [
  path.join(__dirname, 'data'),
  path.join(__dirname, 'users'),
];

// Backup destination
const backupDestination = path.join(__dirname, 'backups');

// Function to copy directory
async function copyDirectory(src, dest) {
  try {
    await fs3.copy(src, dest);
    console.log(`Successfully backed up ${src} to ${dest}`);
  } catch (err) {
    console.error(`Error copying ${src}: ${err}`);
  }
}

// Perform backup
async function performBackup() {
  const timestamp = new Date().toISOString().replace(/:/g, '-'); // Format timestamp
  const backupFolder = path.join(backupDestination, `backup-${timestamp}`);

  try {
    // Create backup directory
    await fs3.ensureDir(backupFolder);

    // Backup each directory
    for (const dir of directoriesToBackup) {
      const backupPath = path.join(backupFolder, path.basename(dir));
      await copyDirectory(dir, backupPath);
    }
  } catch (err) {
    console.error(`Error during backup: ${err}`);
  }
}

// Schedule the backup to run daily at 6:02 AM in the America/New_York timezone
cron.schedule('0 0 * * *', () => {
  console.log('Starting backup process...');
  performBackup();
}, {
  scheduled: true,
  timezone: "America/New_York" // Set your timezone here
});

console.log('Backup service is running...');















// Log in to the Discord bot
client.login(BOT_TOKEN);

// Set the server's port
app.set('port', PORT);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Server is running on port ${PORT}`);
});